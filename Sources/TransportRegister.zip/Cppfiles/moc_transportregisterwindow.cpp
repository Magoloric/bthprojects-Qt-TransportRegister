/****************************************************************************
** Meta object code from reading C++ file 'transportregisterwindow.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.8.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "transportregisterwindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'transportregisterwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.8.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_TransportRegisterWindow_t {
    QByteArrayData data[31];
    char stringdata0[693];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_TransportRegisterWindow_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_TransportRegisterWindow_t qt_meta_stringdata_TransportRegisterWindow = {
    {
QT_MOC_LITERAL(0, 0, 23), // "TransportRegisterWindow"
QT_MOC_LITERAL(1, 24, 19), // "on_PCarView_clicked"
QT_MOC_LITERAL(2, 44, 0), // ""
QT_MOC_LITERAL(3, 45, 5), // "index"
QT_MOC_LITERAL(4, 51, 19), // "on_PVanView_clicked"
QT_MOC_LITERAL(5, 71, 20), // "on_MBikeView_clicked"
QT_MOC_LITERAL(6, 92, 19), // "on_CCarView_clicked"
QT_MOC_LITERAL(7, 112, 19), // "on_CVanView_clicked"
QT_MOC_LITERAL(8, 132, 18), // "on_BusView_clicked"
QT_MOC_LITERAL(9, 151, 25), // "on_PCarView_doubleClicked"
QT_MOC_LITERAL(10, 177, 25), // "on_PVanView_doubleClicked"
QT_MOC_LITERAL(11, 203, 26), // "on_MBikeView_doubleClicked"
QT_MOC_LITERAL(12, 230, 25), // "on_CCarView_doubleClicked"
QT_MOC_LITERAL(13, 256, 25), // "on_CVanView_doubleClicked"
QT_MOC_LITERAL(14, 282, 24), // "on_BusView_doubleClicked"
QT_MOC_LITERAL(15, 307, 24), // "on_addPCarButton_clicked"
QT_MOC_LITERAL(16, 332, 24), // "on_addPVanButton_clicked"
QT_MOC_LITERAL(17, 357, 25), // "on_addMBikeButton_clicked"
QT_MOC_LITERAL(18, 383, 24), // "on_addCCarButton_clicked"
QT_MOC_LITERAL(19, 408, 24), // "on_addCVanButton_clicked"
QT_MOC_LITERAL(20, 433, 23), // "on_addBusButton_clicked"
QT_MOC_LITERAL(21, 457, 21), // "on_quitButton_clicked"
QT_MOC_LITERAL(22, 479, 23), // "on_removeButton_clicked"
QT_MOC_LITERAL(23, 503, 22), // "on_aboutButton_clicked"
QT_MOC_LITERAL(24, 526, 23), // "on_exportButton_clicked"
QT_MOC_LITERAL(25, 550, 23), // "on_importButton_clicked"
QT_MOC_LITERAL(26, 574, 21), // "on_openButton_clicked"
QT_MOC_LITERAL(27, 596, 22), // "on_clearButton_clicked"
QT_MOC_LITERAL(28, 619, 23), // "on_searchButton_clicked"
QT_MOC_LITERAL(29, 643, 25), // "on_lineEdit_returnPressed"
QT_MOC_LITERAL(30, 669, 23) // "on_logoutButton_clicked"

    },
    "TransportRegisterWindow\0on_PCarView_clicked\0"
    "\0index\0on_PVanView_clicked\0"
    "on_MBikeView_clicked\0on_CCarView_clicked\0"
    "on_CVanView_clicked\0on_BusView_clicked\0"
    "on_PCarView_doubleClicked\0"
    "on_PVanView_doubleClicked\0"
    "on_MBikeView_doubleClicked\0"
    "on_CCarView_doubleClicked\0"
    "on_CVanView_doubleClicked\0"
    "on_BusView_doubleClicked\0"
    "on_addPCarButton_clicked\0"
    "on_addPVanButton_clicked\0"
    "on_addMBikeButton_clicked\0"
    "on_addCCarButton_clicked\0"
    "on_addCVanButton_clicked\0"
    "on_addBusButton_clicked\0on_quitButton_clicked\0"
    "on_removeButton_clicked\0on_aboutButton_clicked\0"
    "on_exportButton_clicked\0on_importButton_clicked\0"
    "on_openButton_clicked\0on_clearButton_clicked\0"
    "on_searchButton_clicked\0"
    "on_lineEdit_returnPressed\0"
    "on_logoutButton_clicked"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_TransportRegisterWindow[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      28,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    1,  154,    2, 0x08 /* Private */,
       4,    1,  157,    2, 0x08 /* Private */,
       5,    1,  160,    2, 0x08 /* Private */,
       6,    1,  163,    2, 0x08 /* Private */,
       7,    1,  166,    2, 0x08 /* Private */,
       8,    1,  169,    2, 0x08 /* Private */,
       9,    1,  172,    2, 0x08 /* Private */,
      10,    1,  175,    2, 0x08 /* Private */,
      11,    1,  178,    2, 0x08 /* Private */,
      12,    1,  181,    2, 0x08 /* Private */,
      13,    1,  184,    2, 0x08 /* Private */,
      14,    1,  187,    2, 0x08 /* Private */,
      15,    0,  190,    2, 0x08 /* Private */,
      16,    0,  191,    2, 0x08 /* Private */,
      17,    0,  192,    2, 0x08 /* Private */,
      18,    0,  193,    2, 0x08 /* Private */,
      19,    0,  194,    2, 0x08 /* Private */,
      20,    0,  195,    2, 0x08 /* Private */,
      21,    0,  196,    2, 0x08 /* Private */,
      22,    0,  197,    2, 0x08 /* Private */,
      23,    0,  198,    2, 0x08 /* Private */,
      24,    0,  199,    2, 0x08 /* Private */,
      25,    0,  200,    2, 0x08 /* Private */,
      26,    0,  201,    2, 0x08 /* Private */,
      27,    0,  202,    2, 0x08 /* Private */,
      28,    0,  203,    2, 0x08 /* Private */,
      29,    0,  204,    2, 0x08 /* Private */,
      30,    0,  205,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void, QMetaType::QModelIndex,    3,
    QMetaType::Void, QMetaType::QModelIndex,    3,
    QMetaType::Void, QMetaType::QModelIndex,    3,
    QMetaType::Void, QMetaType::QModelIndex,    3,
    QMetaType::Void, QMetaType::QModelIndex,    3,
    QMetaType::Void, QMetaType::QModelIndex,    3,
    QMetaType::Void, QMetaType::QModelIndex,    3,
    QMetaType::Void, QMetaType::QModelIndex,    3,
    QMetaType::Void, QMetaType::QModelIndex,    3,
    QMetaType::Void, QMetaType::QModelIndex,    3,
    QMetaType::Void, QMetaType::QModelIndex,    3,
    QMetaType::Void, QMetaType::QModelIndex,    3,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void TransportRegisterWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        TransportRegisterWindow *_t = static_cast<TransportRegisterWindow *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->on_PCarView_clicked((*reinterpret_cast< const QModelIndex(*)>(_a[1]))); break;
        case 1: _t->on_PVanView_clicked((*reinterpret_cast< const QModelIndex(*)>(_a[1]))); break;
        case 2: _t->on_MBikeView_clicked((*reinterpret_cast< const QModelIndex(*)>(_a[1]))); break;
        case 3: _t->on_CCarView_clicked((*reinterpret_cast< const QModelIndex(*)>(_a[1]))); break;
        case 4: _t->on_CVanView_clicked((*reinterpret_cast< const QModelIndex(*)>(_a[1]))); break;
        case 5: _t->on_BusView_clicked((*reinterpret_cast< const QModelIndex(*)>(_a[1]))); break;
        case 6: _t->on_PCarView_doubleClicked((*reinterpret_cast< const QModelIndex(*)>(_a[1]))); break;
        case 7: _t->on_PVanView_doubleClicked((*reinterpret_cast< const QModelIndex(*)>(_a[1]))); break;
        case 8: _t->on_MBikeView_doubleClicked((*reinterpret_cast< const QModelIndex(*)>(_a[1]))); break;
        case 9: _t->on_CCarView_doubleClicked((*reinterpret_cast< const QModelIndex(*)>(_a[1]))); break;
        case 10: _t->on_CVanView_doubleClicked((*reinterpret_cast< const QModelIndex(*)>(_a[1]))); break;
        case 11: _t->on_BusView_doubleClicked((*reinterpret_cast< const QModelIndex(*)>(_a[1]))); break;
        case 12: _t->on_addPCarButton_clicked(); break;
        case 13: _t->on_addPVanButton_clicked(); break;
        case 14: _t->on_addMBikeButton_clicked(); break;
        case 15: _t->on_addCCarButton_clicked(); break;
        case 16: _t->on_addCVanButton_clicked(); break;
        case 17: _t->on_addBusButton_clicked(); break;
        case 18: _t->on_quitButton_clicked(); break;
        case 19: _t->on_removeButton_clicked(); break;
        case 20: _t->on_aboutButton_clicked(); break;
        case 21: _t->on_exportButton_clicked(); break;
        case 22: _t->on_importButton_clicked(); break;
        case 23: _t->on_openButton_clicked(); break;
        case 24: _t->on_clearButton_clicked(); break;
        case 25: _t->on_searchButton_clicked(); break;
        case 26: _t->on_lineEdit_returnPressed(); break;
        case 27: _t->on_logoutButton_clicked(); break;
        default: ;
        }
    }
}

const QMetaObject TransportRegisterWindow::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_TransportRegisterWindow.data,
      qt_meta_data_TransportRegisterWindow,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *TransportRegisterWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *TransportRegisterWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_TransportRegisterWindow.stringdata0))
        return static_cast<void*>(const_cast< TransportRegisterWindow*>(this));
    return QMainWindow::qt_metacast(_clname);
}

int TransportRegisterWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 28)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 28;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 28)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 28;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
