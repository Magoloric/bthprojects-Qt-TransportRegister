/********************************************************************************
** Form generated from reading UI file 'addpvandialog.ui'
**
** Created by: Qt User Interface Compiler version 5.8.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ADDPVANDIALOG_H
#define UI_ADDPVANDIALOG_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QDialogButtonBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_addPVanDialog
{
public:
    QDialogButtonBox *addPVanButtonBox;
    QWidget *layoutWidget_4;
    QVBoxLayout *verticalLayout_12;
    QLabel *label_31;
    QLineEdit *model_PV;
    QLabel *label_32;
    QLineEdit *licnr_PV;
    QLabel *label_33;
    QLineEdit *owname_PV;
    QLabel *label_34;
    QLineEdit *ownsur_PV;
    QLabel *label_35;
    QLineEdit *ownid_PV;
    QLabel *label_36;
    QSpinBox *locap_PV;

    void setupUi(QDialog *addPVanDialog)
    {
        if (addPVanDialog->objectName().isEmpty())
            addPVanDialog->setObjectName(QStringLiteral("addPVanDialog"));
        addPVanDialog->resize(388, 450);
        addPVanButtonBox = new QDialogButtonBox(addPVanDialog);
        addPVanButtonBox->setObjectName(QStringLiteral("addPVanButtonBox"));
        addPVanButtonBox->setGeometry(QRect(10, 410, 341, 32));
        addPVanButtonBox->setOrientation(Qt::Horizontal);
        addPVanButtonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);
        layoutWidget_4 = new QWidget(addPVanDialog);
        layoutWidget_4->setObjectName(QStringLiteral("layoutWidget_4"));
        layoutWidget_4->setGeometry(QRect(10, 15, 341, 391));
        verticalLayout_12 = new QVBoxLayout(layoutWidget_4);
        verticalLayout_12->setObjectName(QStringLiteral("verticalLayout_12"));
        verticalLayout_12->setContentsMargins(0, 0, 0, 0);
        label_31 = new QLabel(layoutWidget_4);
        label_31->setObjectName(QStringLiteral("label_31"));

        verticalLayout_12->addWidget(label_31);

        model_PV = new QLineEdit(layoutWidget_4);
        model_PV->setObjectName(QStringLiteral("model_PV"));

        verticalLayout_12->addWidget(model_PV);

        label_32 = new QLabel(layoutWidget_4);
        label_32->setObjectName(QStringLiteral("label_32"));

        verticalLayout_12->addWidget(label_32);

        licnr_PV = new QLineEdit(layoutWidget_4);
        licnr_PV->setObjectName(QStringLiteral("licnr_PV"));

        verticalLayout_12->addWidget(licnr_PV);

        label_33 = new QLabel(layoutWidget_4);
        label_33->setObjectName(QStringLiteral("label_33"));

        verticalLayout_12->addWidget(label_33);

        owname_PV = new QLineEdit(layoutWidget_4);
        owname_PV->setObjectName(QStringLiteral("owname_PV"));

        verticalLayout_12->addWidget(owname_PV);

        label_34 = new QLabel(layoutWidget_4);
        label_34->setObjectName(QStringLiteral("label_34"));

        verticalLayout_12->addWidget(label_34);

        ownsur_PV = new QLineEdit(layoutWidget_4);
        ownsur_PV->setObjectName(QStringLiteral("ownsur_PV"));

        verticalLayout_12->addWidget(ownsur_PV);

        label_35 = new QLabel(layoutWidget_4);
        label_35->setObjectName(QStringLiteral("label_35"));

        verticalLayout_12->addWidget(label_35);

        ownid_PV = new QLineEdit(layoutWidget_4);
        ownid_PV->setObjectName(QStringLiteral("ownid_PV"));

        verticalLayout_12->addWidget(ownid_PV);

        label_36 = new QLabel(layoutWidget_4);
        label_36->setObjectName(QStringLiteral("label_36"));

        verticalLayout_12->addWidget(label_36);

        locap_PV = new QSpinBox(layoutWidget_4);
        locap_PV->setObjectName(QStringLiteral("locap_PV"));
        locap_PV->setMaximum(99999);

        verticalLayout_12->addWidget(locap_PV);


        retranslateUi(addPVanDialog);
        QObject::connect(addPVanButtonBox, SIGNAL(accepted()), addPVanDialog, SLOT(accept()));
        QObject::connect(addPVanButtonBox, SIGNAL(rejected()), addPVanDialog, SLOT(reject()));

        QMetaObject::connectSlotsByName(addPVanDialog);
    } // setupUi

    void retranslateUi(QDialog *addPVanDialog)
    {
        addPVanDialog->setWindowTitle(QApplication::translate("addPVanDialog", "Add private van", Q_NULLPTR));
        label_31->setText(QApplication::translate("addPVanDialog", "Model:", Q_NULLPTR));
        label_32->setText(QApplication::translate("addPVanDialog", "License Number:", Q_NULLPTR));
        label_33->setText(QApplication::translate("addPVanDialog", "Owner Name:", Q_NULLPTR));
        label_34->setText(QApplication::translate("addPVanDialog", "Owner Surname:", Q_NULLPTR));
        label_35->setText(QApplication::translate("addPVanDialog", "Owner Civic ID:", Q_NULLPTR));
        label_36->setText(QApplication::translate("addPVanDialog", "Load capacity:", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class addPVanDialog: public Ui_addPVanDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ADDPVANDIALOG_H
