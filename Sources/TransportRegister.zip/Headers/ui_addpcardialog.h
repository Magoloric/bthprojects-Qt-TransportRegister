/********************************************************************************
** Form generated from reading UI file 'addpcardialog.ui'
**
** Created by: Qt User Interface Compiler version 5.8.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ADDPCARDIALOG_H
#define UI_ADDPCARDIALOG_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QDialogButtonBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_addPCarDialog
{
public:
    QWidget *layoutWidget;
    QVBoxLayout *verticalLayout_3;
    QLabel *label_7;
    QLineEdit *modl;
    QLabel *label_8;
    QLineEdit *lcnr;
    QLabel *label_9;
    QLineEdit *owNa;
    QLabel *label_10;
    QLineEdit *owSu;
    QLabel *label_11;
    QLineEdit *owID;
    QLabel *label_12;
    QLineEdit *ensu;
    QDialogButtonBox *addPCarButtonBox;

    void setupUi(QDialog *addPCarDialog)
    {
        if (addPCarDialog->objectName().isEmpty())
            addPCarDialog->setObjectName(QStringLiteral("addPCarDialog"));
        addPCarDialog->resize(364, 439);
        layoutWidget = new QWidget(addPCarDialog);
        layoutWidget->setObjectName(QStringLiteral("layoutWidget"));
        layoutWidget->setGeometry(QRect(10, 20, 341, 361));
        verticalLayout_3 = new QVBoxLayout(layoutWidget);
        verticalLayout_3->setObjectName(QStringLiteral("verticalLayout_3"));
        verticalLayout_3->setContentsMargins(0, 0, 0, 0);
        label_7 = new QLabel(layoutWidget);
        label_7->setObjectName(QStringLiteral("label_7"));

        verticalLayout_3->addWidget(label_7);

        modl = new QLineEdit(layoutWidget);
        modl->setObjectName(QStringLiteral("modl"));

        verticalLayout_3->addWidget(modl);

        label_8 = new QLabel(layoutWidget);
        label_8->setObjectName(QStringLiteral("label_8"));

        verticalLayout_3->addWidget(label_8);

        lcnr = new QLineEdit(layoutWidget);
        lcnr->setObjectName(QStringLiteral("lcnr"));

        verticalLayout_3->addWidget(lcnr);

        label_9 = new QLabel(layoutWidget);
        label_9->setObjectName(QStringLiteral("label_9"));

        verticalLayout_3->addWidget(label_9);

        owNa = new QLineEdit(layoutWidget);
        owNa->setObjectName(QStringLiteral("owNa"));

        verticalLayout_3->addWidget(owNa);

        label_10 = new QLabel(layoutWidget);
        label_10->setObjectName(QStringLiteral("label_10"));

        verticalLayout_3->addWidget(label_10);

        owSu = new QLineEdit(layoutWidget);
        owSu->setObjectName(QStringLiteral("owSu"));

        verticalLayout_3->addWidget(owSu);

        label_11 = new QLabel(layoutWidget);
        label_11->setObjectName(QStringLiteral("label_11"));

        verticalLayout_3->addWidget(label_11);

        owID = new QLineEdit(layoutWidget);
        owID->setObjectName(QStringLiteral("owID"));

        verticalLayout_3->addWidget(owID);

        label_12 = new QLabel(layoutWidget);
        label_12->setObjectName(QStringLiteral("label_12"));

        verticalLayout_3->addWidget(label_12);

        ensu = new QLineEdit(layoutWidget);
        ensu->setObjectName(QStringLiteral("ensu"));

        verticalLayout_3->addWidget(ensu);

        addPCarButtonBox = new QDialogButtonBox(addPCarDialog);
        addPCarButtonBox->setObjectName(QStringLiteral("addPCarButtonBox"));
        addPCarButtonBox->setGeometry(QRect(130, 390, 271, 32));
        addPCarButtonBox->setOrientation(Qt::Horizontal);
        addPCarButtonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);
        addPCarButtonBox->setCenterButtons(true);

        retranslateUi(addPCarDialog);
        QObject::connect(addPCarButtonBox, SIGNAL(accepted()), addPCarDialog, SLOT(accept()));
        QObject::connect(addPCarButtonBox, SIGNAL(rejected()), addPCarDialog, SLOT(reject()));

        QMetaObject::connectSlotsByName(addPCarDialog);
    } // setupUi

    void retranslateUi(QDialog *addPCarDialog)
    {
        addPCarDialog->setWindowTitle(QApplication::translate("addPCarDialog", "Add private car", Q_NULLPTR));
        label_7->setText(QApplication::translate("addPCarDialog", "Model:", Q_NULLPTR));
        label_8->setText(QApplication::translate("addPCarDialog", "License Number:", Q_NULLPTR));
        label_9->setText(QApplication::translate("addPCarDialog", "Owner Name:", Q_NULLPTR));
        label_10->setText(QApplication::translate("addPCarDialog", "Owner Surname:", Q_NULLPTR));
        label_11->setText(QApplication::translate("addPCarDialog", "Owner Civic ID:", Q_NULLPTR));
        label_12->setText(QApplication::translate("addPCarDialog", "Ensured by:", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class addPCarDialog: public Ui_addPCarDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ADDPCARDIALOG_H
