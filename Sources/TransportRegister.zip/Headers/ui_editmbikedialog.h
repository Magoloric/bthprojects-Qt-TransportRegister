/********************************************************************************
** Form generated from reading UI file 'editmbikedialog.ui'
**
** Created by: Qt User Interface Compiler version 5.8.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_EDITMBIKEDIALOG_H
#define UI_EDITMBIKEDIALOG_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QDialogButtonBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_editmbikedialog
{
public:
    QDialogButtonBox *buttonBox;
    QWidget *layoutWidget_5;
    QVBoxLayout *verticalLayout_13;
    QLabel *label_37;
    QLineEdit *model_MB;
    QLabel *label_39;
    QLineEdit *owname_MB;
    QLabel *label_40;
    QLineEdit *ownsur_MB;
    QLabel *label_41;
    QLineEdit *ownid_MB;
    QLabel *label_42;
    QSpinBox *maxspe;
    QLabel *label_61;
    QSpinBox *swepvo;

    void setupUi(QDialog *editmbikedialog)
    {
        if (editmbikedialog->objectName().isEmpty())
            editmbikedialog->setObjectName(QStringLiteral("editmbikedialog"));
        editmbikedialog->resize(406, 420);
        buttonBox = new QDialogButtonBox(editmbikedialog);
        buttonBox->setObjectName(QStringLiteral("buttonBox"));
        buttonBox->setGeometry(QRect(50, 360, 341, 32));
        buttonBox->setOrientation(Qt::Horizontal);
        buttonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);
        layoutWidget_5 = new QWidget(editmbikedialog);
        layoutWidget_5->setObjectName(QStringLiteral("layoutWidget_5"));
        layoutWidget_5->setGeometry(QRect(20, 20, 371, 331));
        verticalLayout_13 = new QVBoxLayout(layoutWidget_5);
        verticalLayout_13->setObjectName(QStringLiteral("verticalLayout_13"));
        verticalLayout_13->setContentsMargins(0, 0, 0, 0);
        label_37 = new QLabel(layoutWidget_5);
        label_37->setObjectName(QStringLiteral("label_37"));

        verticalLayout_13->addWidget(label_37);

        model_MB = new QLineEdit(layoutWidget_5);
        model_MB->setObjectName(QStringLiteral("model_MB"));

        verticalLayout_13->addWidget(model_MB);

        label_39 = new QLabel(layoutWidget_5);
        label_39->setObjectName(QStringLiteral("label_39"));

        verticalLayout_13->addWidget(label_39);

        owname_MB = new QLineEdit(layoutWidget_5);
        owname_MB->setObjectName(QStringLiteral("owname_MB"));

        verticalLayout_13->addWidget(owname_MB);

        label_40 = new QLabel(layoutWidget_5);
        label_40->setObjectName(QStringLiteral("label_40"));

        verticalLayout_13->addWidget(label_40);

        ownsur_MB = new QLineEdit(layoutWidget_5);
        ownsur_MB->setObjectName(QStringLiteral("ownsur_MB"));

        verticalLayout_13->addWidget(ownsur_MB);

        label_41 = new QLabel(layoutWidget_5);
        label_41->setObjectName(QStringLiteral("label_41"));

        verticalLayout_13->addWidget(label_41);

        ownid_MB = new QLineEdit(layoutWidget_5);
        ownid_MB->setObjectName(QStringLiteral("ownid_MB"));

        verticalLayout_13->addWidget(ownid_MB);

        label_42 = new QLabel(layoutWidget_5);
        label_42->setObjectName(QStringLiteral("label_42"));

        verticalLayout_13->addWidget(label_42);

        maxspe = new QSpinBox(layoutWidget_5);
        maxspe->setObjectName(QStringLiteral("maxspe"));
        maxspe->setMaximum(200);

        verticalLayout_13->addWidget(maxspe);

        label_61 = new QLabel(layoutWidget_5);
        label_61->setObjectName(QStringLiteral("label_61"));

        verticalLayout_13->addWidget(label_61);

        swepvo = new QSpinBox(layoutWidget_5);
        swepvo->setObjectName(QStringLiteral("swepvo"));
        swepvo->setMaximum(9999);

        verticalLayout_13->addWidget(swepvo);


        retranslateUi(editmbikedialog);
        QObject::connect(buttonBox, SIGNAL(accepted()), editmbikedialog, SLOT(accept()));
        QObject::connect(buttonBox, SIGNAL(rejected()), editmbikedialog, SLOT(reject()));

        QMetaObject::connectSlotsByName(editmbikedialog);
    } // setupUi

    void retranslateUi(QDialog *editmbikedialog)
    {
        editmbikedialog->setWindowTitle(QApplication::translate("editmbikedialog", "Edit motorbike", Q_NULLPTR));
        label_37->setText(QApplication::translate("editmbikedialog", "Model:", Q_NULLPTR));
        label_39->setText(QApplication::translate("editmbikedialog", "Owner Name:", Q_NULLPTR));
        label_40->setText(QApplication::translate("editmbikedialog", "Owner Surname:", Q_NULLPTR));
        label_41->setText(QApplication::translate("editmbikedialog", "Owner Civic ID:", Q_NULLPTR));
        label_42->setText(QApplication::translate("editmbikedialog", "Maximal Speed", Q_NULLPTR));
        label_61->setText(QApplication::translate("editmbikedialog", "Swept Volume", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class editmbikedialog: public Ui_editmbikedialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_EDITMBIKEDIALOG_H
