/********************************************************************************
** Form generated from reading UI file 'login.ui'
**
** Created by: Qt User Interface Compiler version 5.8.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_LOGIN_H
#define UI_LOGIN_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Login
{
public:
    QLineEdit *userLine;
    QLineEdit *passLine;
    QLabel *label;
    QLabel *label_2;
    QLabel *label_3;
    QWidget *layoutWidget;
    QHBoxLayout *horizontalLayout;
    QPushButton *loginButton;
    QPushButton *closeButton;
    QLabel *label_4;
    QComboBox *groupBox;

    void setupUi(QDialog *Login)
    {
        if (Login->objectName().isEmpty())
            Login->setObjectName(QStringLiteral("Login"));
        Login->resize(400, 378);
        userLine = new QLineEdit(Login);
        userLine->setObjectName(QStringLiteral("userLine"));
        userLine->setGeometry(QRect(110, 150, 271, 31));
        passLine = new QLineEdit(Login);
        passLine->setObjectName(QStringLiteral("passLine"));
        passLine->setGeometry(QRect(110, 200, 271, 31));
        passLine->setEchoMode(QLineEdit::Password);
        label = new QLabel(Login);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(20, 150, 81, 31));
        label_2 = new QLabel(Login);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(20, 200, 91, 31));
        label_3 = new QLabel(Login);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(180, 20, 201, 41));
        layoutWidget = new QWidget(Login);
        layoutWidget->setObjectName(QStringLiteral("layoutWidget"));
        layoutWidget->setGeometry(QRect(30, 290, 341, 51));
        horizontalLayout = new QHBoxLayout(layoutWidget);
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        loginButton = new QPushButton(layoutWidget);
        loginButton->setObjectName(QStringLiteral("loginButton"));

        horizontalLayout->addWidget(loginButton);

        closeButton = new QPushButton(layoutWidget);
        closeButton->setObjectName(QStringLiteral("closeButton"));

        horizontalLayout->addWidget(closeButton);

        label_4 = new QLabel(Login);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setGeometry(QRect(20, 100, 61, 31));
        groupBox = new QComboBox(Login);
        groupBox->setObjectName(QStringLiteral("groupBox"));
        groupBox->setGeometry(QRect(110, 101, 271, 31));

        retranslateUi(Login);
        QObject::connect(closeButton, SIGNAL(clicked()), Login, SLOT(close()));

        QMetaObject::connectSlotsByName(Login);
    } // setupUi

    void retranslateUi(QDialog *Login)
    {
        Login->setWindowTitle(QApplication::translate("Login", "User Login", Q_NULLPTR));
        passLine->setInputMask(QString());
        passLine->setText(QString());
        label->setText(QApplication::translate("Login", "Username:", Q_NULLPTR));
        label_2->setText(QApplication::translate("Login", "Password:", Q_NULLPTR));
        label_3->setText(QApplication::translate("Login", "Please log in", Q_NULLPTR));
        loginButton->setText(QApplication::translate("Login", "Login", Q_NULLPTR));
        closeButton->setText(QApplication::translate("Login", "Close", Q_NULLPTR));
        label_4->setText(QApplication::translate("Login", "Group:", Q_NULLPTR));
        groupBox->clear();
        groupBox->insertItems(0, QStringList()
         << QApplication::translate("Login", "USER", Q_NULLPTR)
         << QApplication::translate("Login", "COMPANY", Q_NULLPTR)
         << QApplication::translate("Login", "ADMIN", Q_NULLPTR)
        );
    } // retranslateUi

};

namespace Ui {
    class Login: public Ui_Login {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_LOGIN_H
