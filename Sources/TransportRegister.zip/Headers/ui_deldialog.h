/********************************************************************************
** Form generated from reading UI file 'deldialog.ui'
**
** Created by: Qt User Interface Compiler version 5.8.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DELDIALOG_H
#define UI_DELDIALOG_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QDialogButtonBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>

QT_BEGIN_NAMESPACE

class Ui_deldialog
{
public:
    QDialogButtonBox *RemoveButtonBox;
    QLineEdit *remLicNr;
    QLabel *label;

    void setupUi(QDialog *deldialog)
    {
        if (deldialog->objectName().isEmpty())
            deldialog->setObjectName(QStringLiteral("deldialog"));
        deldialog->resize(400, 190);
        RemoveButtonBox = new QDialogButtonBox(deldialog);
        RemoveButtonBox->setObjectName(QStringLiteral("RemoveButtonBox"));
        RemoveButtonBox->setGeometry(QRect(30, 120, 341, 32));
        RemoveButtonBox->setOrientation(Qt::Horizontal);
        RemoveButtonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);
        remLicNr = new QLineEdit(deldialog);
        remLicNr->setObjectName(QStringLiteral("remLicNr"));
        remLicNr->setGeometry(QRect(20, 60, 351, 21));
        label = new QLabel(deldialog);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(20, 30, 351, 31));

        retranslateUi(deldialog);
        QObject::connect(RemoveButtonBox, SIGNAL(rejected()), deldialog, SLOT(reject()));
        QObject::connect(RemoveButtonBox, SIGNAL(accepted()), deldialog, SLOT(accept()));

        QMetaObject::connectSlotsByName(deldialog);
    } // setupUi

    void retranslateUi(QDialog *deldialog)
    {
        deldialog->setWindowTitle(QApplication::translate("deldialog", "Remove transport", Q_NULLPTR));
#ifndef QT_NO_STATUSTIP
        RemoveButtonBox->setStatusTip(QApplication::translate("deldialog", "Remove transport", Q_NULLPTR));
#endif // QT_NO_STATUSTIP
#ifndef QT_NO_WHATSTHIS
        RemoveButtonBox->setWhatsThis(QApplication::translate("deldialog", "Remove transport", Q_NULLPTR));
#endif // QT_NO_WHATSTHIS
#ifndef QT_NO_ACCESSIBILITY
        RemoveButtonBox->setAccessibleName(QApplication::translate("deldialog", "Remove transport", "Remove transport"));
#endif // QT_NO_ACCESSIBILITY
        label->setText(QApplication::translate("deldialog", "License number:", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class deldialog: public Ui_deldialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DELDIALOG_H
