/********************************************************************************
** Form generated from reading UI file 'editccardialog.ui'
**
** Created by: Qt User Interface Compiler version 5.8.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_EDITCCARDIALOG_H
#define UI_EDITCCARDIALOG_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QDialogButtonBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_editCCarDialog
{
public:
    QDialogButtonBox *buttonBox;
    QWidget *layoutWidget_14;
    QVBoxLayout *verticalLayout_22;
    QLabel *label_47;
    QLineEdit *model_CC_2;
    QLabel *label_61;
    QLineEdit *comname_CC_2;
    QLabel *label_63;
    QLineEdit *orgnr_CC_2;
    QLabel *label_64;
    QLineEdit *ensur_CC_2;

    void setupUi(QDialog *editCCarDialog)
    {
        if (editCCarDialog->objectName().isEmpty())
            editCCarDialog->setObjectName(QStringLiteral("editCCarDialog"));
        editCCarDialog->resize(352, 300);
        buttonBox = new QDialogButtonBox(editCCarDialog);
        buttonBox->setObjectName(QStringLiteral("buttonBox"));
        buttonBox->setGeometry(QRect(0, 260, 341, 32));
        buttonBox->setOrientation(Qt::Horizontal);
        buttonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);
        layoutWidget_14 = new QWidget(editCCarDialog);
        layoutWidget_14->setObjectName(QStringLiteral("layoutWidget_14"));
        layoutWidget_14->setGeometry(QRect(10, 10, 331, 241));
        verticalLayout_22 = new QVBoxLayout(layoutWidget_14);
        verticalLayout_22->setObjectName(QStringLiteral("verticalLayout_22"));
        verticalLayout_22->setContentsMargins(0, 0, 0, 0);
        label_47 = new QLabel(layoutWidget_14);
        label_47->setObjectName(QStringLiteral("label_47"));

        verticalLayout_22->addWidget(label_47);

        model_CC_2 = new QLineEdit(layoutWidget_14);
        model_CC_2->setObjectName(QStringLiteral("model_CC_2"));

        verticalLayout_22->addWidget(model_CC_2);

        label_61 = new QLabel(layoutWidget_14);
        label_61->setObjectName(QStringLiteral("label_61"));

        verticalLayout_22->addWidget(label_61);

        comname_CC_2 = new QLineEdit(layoutWidget_14);
        comname_CC_2->setObjectName(QStringLiteral("comname_CC_2"));

        verticalLayout_22->addWidget(comname_CC_2);

        label_63 = new QLabel(layoutWidget_14);
        label_63->setObjectName(QStringLiteral("label_63"));

        verticalLayout_22->addWidget(label_63);

        orgnr_CC_2 = new QLineEdit(layoutWidget_14);
        orgnr_CC_2->setObjectName(QStringLiteral("orgnr_CC_2"));

        verticalLayout_22->addWidget(orgnr_CC_2);

        label_64 = new QLabel(layoutWidget_14);
        label_64->setObjectName(QStringLiteral("label_64"));

        verticalLayout_22->addWidget(label_64);

        ensur_CC_2 = new QLineEdit(layoutWidget_14);
        ensur_CC_2->setObjectName(QStringLiteral("ensur_CC_2"));

        verticalLayout_22->addWidget(ensur_CC_2);

        buttonBox->raise();
        layoutWidget_14->raise();
        label_64->raise();

        retranslateUi(editCCarDialog);
        QObject::connect(buttonBox, SIGNAL(accepted()), editCCarDialog, SLOT(accept()));
        QObject::connect(buttonBox, SIGNAL(rejected()), editCCarDialog, SLOT(reject()));

        QMetaObject::connectSlotsByName(editCCarDialog);
    } // setupUi

    void retranslateUi(QDialog *editCCarDialog)
    {
        editCCarDialog->setWindowTitle(QApplication::translate("editCCarDialog", "Edit company car", Q_NULLPTR));
        label_47->setText(QApplication::translate("editCCarDialog", "Model:", Q_NULLPTR));
        label_61->setText(QApplication::translate("editCCarDialog", "Company Name", Q_NULLPTR));
        label_63->setText(QApplication::translate("editCCarDialog", "Organization Number:", Q_NULLPTR));
        label_64->setText(QApplication::translate("editCCarDialog", "Ensured by:", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class editCCarDialog: public Ui_editCCarDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_EDITCCARDIALOG_H
