/********************************************************************************
** Form generated from reading UI file 'addbusdialog.ui'
**
** Created by: Qt User Interface Compiler version 5.8.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ADDBUSDIALOG_H
#define UI_ADDBUSDIALOG_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QDialogButtonBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_addBusDialog
{
public:
    QDialogButtonBox *addBusButtonBox;
    QWidget *layoutWidget_12;
    QVBoxLayout *verticalLayout_20;
    QLabel *label_55;
    QLineEdit *model_B;
    QLabel *label_56;
    QLineEdit *licnr_B;
    QLabel *label_57;
    QLineEdit *comname_B;
    QLabel *label_58;
    QLineEdit *orgnr_B;
    QLabel *label_59;
    QLineEdit *bustyp;
    QLabel *label_60;
    QSpinBox *insnr;
    QLabel *label_62;
    QSpinBox *nrofsea;

    void setupUi(QDialog *addBusDialog)
    {
        if (addBusDialog->objectName().isEmpty())
            addBusDialog->setObjectName(QStringLiteral("addBusDialog"));
        addBusDialog->resize(470, 590);
        addBusButtonBox = new QDialogButtonBox(addBusDialog);
        addBusButtonBox->setObjectName(QStringLiteral("addBusButtonBox"));
        addBusButtonBox->setGeometry(QRect(80, 530, 341, 32));
        addBusButtonBox->setOrientation(Qt::Horizontal);
        addBusButtonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);
        layoutWidget_12 = new QWidget(addBusDialog);
        layoutWidget_12->setObjectName(QStringLiteral("layoutWidget_12"));
        layoutWidget_12->setGeometry(QRect(10, 20, 411, 471));
        verticalLayout_20 = new QVBoxLayout(layoutWidget_12);
        verticalLayout_20->setObjectName(QStringLiteral("verticalLayout_20"));
        verticalLayout_20->setContentsMargins(0, 0, 0, 0);
        label_55 = new QLabel(layoutWidget_12);
        label_55->setObjectName(QStringLiteral("label_55"));

        verticalLayout_20->addWidget(label_55);

        model_B = new QLineEdit(layoutWidget_12);
        model_B->setObjectName(QStringLiteral("model_B"));

        verticalLayout_20->addWidget(model_B);

        label_56 = new QLabel(layoutWidget_12);
        label_56->setObjectName(QStringLiteral("label_56"));

        verticalLayout_20->addWidget(label_56);

        licnr_B = new QLineEdit(layoutWidget_12);
        licnr_B->setObjectName(QStringLiteral("licnr_B"));

        verticalLayout_20->addWidget(licnr_B);

        label_57 = new QLabel(layoutWidget_12);
        label_57->setObjectName(QStringLiteral("label_57"));

        verticalLayout_20->addWidget(label_57);

        comname_B = new QLineEdit(layoutWidget_12);
        comname_B->setObjectName(QStringLiteral("comname_B"));

        verticalLayout_20->addWidget(comname_B);

        label_58 = new QLabel(layoutWidget_12);
        label_58->setObjectName(QStringLiteral("label_58"));

        verticalLayout_20->addWidget(label_58);

        orgnr_B = new QLineEdit(layoutWidget_12);
        orgnr_B->setObjectName(QStringLiteral("orgnr_B"));

        verticalLayout_20->addWidget(orgnr_B);

        label_59 = new QLabel(layoutWidget_12);
        label_59->setObjectName(QStringLiteral("label_59"));

        verticalLayout_20->addWidget(label_59);

        bustyp = new QLineEdit(layoutWidget_12);
        bustyp->setObjectName(QStringLiteral("bustyp"));

        verticalLayout_20->addWidget(bustyp);

        label_60 = new QLabel(layoutWidget_12);
        label_60->setObjectName(QStringLiteral("label_60"));

        verticalLayout_20->addWidget(label_60);

        insnr = new QSpinBox(layoutWidget_12);
        insnr->setObjectName(QStringLiteral("insnr"));
        insnr->setMaximum(99999);

        verticalLayout_20->addWidget(insnr);

        label_62 = new QLabel(layoutWidget_12);
        label_62->setObjectName(QStringLiteral("label_62"));

        verticalLayout_20->addWidget(label_62);

        nrofsea = new QSpinBox(layoutWidget_12);
        nrofsea->setObjectName(QStringLiteral("nrofsea"));
        nrofsea->setMaximum(200);

        verticalLayout_20->addWidget(nrofsea);


        retranslateUi(addBusDialog);
        QObject::connect(addBusButtonBox, SIGNAL(accepted()), addBusDialog, SLOT(accept()));
        QObject::connect(addBusButtonBox, SIGNAL(rejected()), addBusDialog, SLOT(reject()));
        QObject::connect(licnr_B, SIGNAL(textEdited(QString)), addBusButtonBox, SLOT(show()));

        QMetaObject::connectSlotsByName(addBusDialog);
    } // setupUi

    void retranslateUi(QDialog *addBusDialog)
    {
        addBusDialog->setWindowTitle(QApplication::translate("addBusDialog", "Add bus", Q_NULLPTR));
        label_55->setText(QApplication::translate("addBusDialog", "Model:", Q_NULLPTR));
        label_56->setText(QApplication::translate("addBusDialog", "License Number:", Q_NULLPTR));
        label_57->setText(QApplication::translate("addBusDialog", "Company Name:", Q_NULLPTR));
        label_58->setText(QApplication::translate("addBusDialog", "Organization Number:", Q_NULLPTR));
        label_59->setText(QApplication::translate("addBusDialog", "Bus type:", Q_NULLPTR));
        label_60->setText(QApplication::translate("addBusDialog", "Inside Number:", Q_NULLPTR));
        label_62->setText(QApplication::translate("addBusDialog", "Number of seats:", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class addBusDialog: public Ui_addBusDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ADDBUSDIALOG_H
