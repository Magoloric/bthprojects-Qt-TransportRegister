/********************************************************************************
** Form generated from reading UI file 'addmbikedialog.ui'
**
** Created by: Qt User Interface Compiler version 5.8.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ADDMBIKEDIALOG_H
#define UI_ADDMBIKEDIALOG_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QDialogButtonBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_addMBikeDialog
{
public:
    QDialogButtonBox *addMBikeButtonBox;
    QWidget *layoutWidget_6;
    QVBoxLayout *verticalLayout_14;
    QLabel *label_37;
    QLineEdit *model_MB;
    QLabel *label_38;
    QLineEdit *licnr_MB;
    QLabel *label_39;
    QLineEdit *owname_MB;
    QLabel *label_40;
    QLineEdit *ownsur_MB;
    QLabel *label_41;
    QLineEdit *ownid_MB;
    QLabel *label_42;
    QSpinBox *maxspe;
    QLabel *label_61;
    QSpinBox *swepvo;

    void setupUi(QDialog *addMBikeDialog)
    {
        if (addMBikeDialog->objectName().isEmpty())
            addMBikeDialog->setObjectName(QStringLiteral("addMBikeDialog"));
        addMBikeDialog->resize(373, 501);
        addMBikeButtonBox = new QDialogButtonBox(addMBikeDialog);
        addMBikeButtonBox->setObjectName(QStringLiteral("addMBikeButtonBox"));
        addMBikeButtonBox->setGeometry(QRect(10, 460, 341, 32));
        addMBikeButtonBox->setOrientation(Qt::Horizontal);
        addMBikeButtonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);
        layoutWidget_6 = new QWidget(addMBikeDialog);
        layoutWidget_6->setObjectName(QStringLiteral("layoutWidget_6"));
        layoutWidget_6->setGeometry(QRect(10, 10, 341, 441));
        verticalLayout_14 = new QVBoxLayout(layoutWidget_6);
        verticalLayout_14->setObjectName(QStringLiteral("verticalLayout_14"));
        verticalLayout_14->setContentsMargins(0, 0, 0, 0);
        label_37 = new QLabel(layoutWidget_6);
        label_37->setObjectName(QStringLiteral("label_37"));

        verticalLayout_14->addWidget(label_37);

        model_MB = new QLineEdit(layoutWidget_6);
        model_MB->setObjectName(QStringLiteral("model_MB"));

        verticalLayout_14->addWidget(model_MB);

        label_38 = new QLabel(layoutWidget_6);
        label_38->setObjectName(QStringLiteral("label_38"));

        verticalLayout_14->addWidget(label_38);

        licnr_MB = new QLineEdit(layoutWidget_6);
        licnr_MB->setObjectName(QStringLiteral("licnr_MB"));

        verticalLayout_14->addWidget(licnr_MB);

        label_39 = new QLabel(layoutWidget_6);
        label_39->setObjectName(QStringLiteral("label_39"));

        verticalLayout_14->addWidget(label_39);

        owname_MB = new QLineEdit(layoutWidget_6);
        owname_MB->setObjectName(QStringLiteral("owname_MB"));

        verticalLayout_14->addWidget(owname_MB);

        label_40 = new QLabel(layoutWidget_6);
        label_40->setObjectName(QStringLiteral("label_40"));

        verticalLayout_14->addWidget(label_40);

        ownsur_MB = new QLineEdit(layoutWidget_6);
        ownsur_MB->setObjectName(QStringLiteral("ownsur_MB"));

        verticalLayout_14->addWidget(ownsur_MB);

        label_41 = new QLabel(layoutWidget_6);
        label_41->setObjectName(QStringLiteral("label_41"));

        verticalLayout_14->addWidget(label_41);

        ownid_MB = new QLineEdit(layoutWidget_6);
        ownid_MB->setObjectName(QStringLiteral("ownid_MB"));

        verticalLayout_14->addWidget(ownid_MB);

        label_42 = new QLabel(layoutWidget_6);
        label_42->setObjectName(QStringLiteral("label_42"));

        verticalLayout_14->addWidget(label_42);

        maxspe = new QSpinBox(layoutWidget_6);
        maxspe->setObjectName(QStringLiteral("maxspe"));
        maxspe->setMaximum(200);

        verticalLayout_14->addWidget(maxspe);

        label_61 = new QLabel(layoutWidget_6);
        label_61->setObjectName(QStringLiteral("label_61"));

        verticalLayout_14->addWidget(label_61);

        swepvo = new QSpinBox(layoutWidget_6);
        swepvo->setObjectName(QStringLiteral("swepvo"));
        swepvo->setMaximum(9999);

        verticalLayout_14->addWidget(swepvo);


        retranslateUi(addMBikeDialog);
        QObject::connect(addMBikeButtonBox, SIGNAL(accepted()), addMBikeDialog, SLOT(accept()));
        QObject::connect(addMBikeButtonBox, SIGNAL(rejected()), addMBikeDialog, SLOT(reject()));

        QMetaObject::connectSlotsByName(addMBikeDialog);
    } // setupUi

    void retranslateUi(QDialog *addMBikeDialog)
    {
        addMBikeDialog->setWindowTitle(QApplication::translate("addMBikeDialog", "Add motorbike", Q_NULLPTR));
        label_37->setText(QApplication::translate("addMBikeDialog", "Model:", Q_NULLPTR));
        label_38->setText(QApplication::translate("addMBikeDialog", "License Number:", Q_NULLPTR));
        label_39->setText(QApplication::translate("addMBikeDialog", "Owner Name:", Q_NULLPTR));
        label_40->setText(QApplication::translate("addMBikeDialog", "Owner Surname:", Q_NULLPTR));
        label_41->setText(QApplication::translate("addMBikeDialog", "Owner Civic ID:", Q_NULLPTR));
        label_42->setText(QApplication::translate("addMBikeDialog", "Maximal Speed", Q_NULLPTR));
        label_61->setText(QApplication::translate("addMBikeDialog", "Swept Volume", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class addMBikeDialog: public Ui_addMBikeDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ADDMBIKEDIALOG_H
