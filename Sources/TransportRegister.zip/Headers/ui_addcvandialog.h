/********************************************************************************
** Form generated from reading UI file 'addcvandialog.ui'
**
** Created by: Qt User Interface Compiler version 5.8.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ADDCVANDIALOG_H
#define UI_ADDCVANDIALOG_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QDialogButtonBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_addCVanDialog
{
public:
    QDialogButtonBox *addCVanButtonBox;
    QWidget *layoutWidget_10;
    QVBoxLayout *verticalLayout_18;
    QLabel *label_49;
    QLineEdit *model_CV;
    QLabel *label_50;
    QLineEdit *licnr_CV;
    QLabel *label_51;
    QLineEdit *comname_CV;
    QLabel *label_52;
    QLineEdit *orgnr_CV;
    QLabel *label_54;
    QSpinBox *loacap_CV;

    void setupUi(QDialog *addCVanDialog)
    {
        if (addCVanDialog->objectName().isEmpty())
            addCVanDialog->setObjectName(QStringLiteral("addCVanDialog"));
        addCVanDialog->resize(380, 454);
        addCVanButtonBox = new QDialogButtonBox(addCVanDialog);
        addCVanButtonBox->setObjectName(QStringLiteral("addCVanButtonBox"));
        addCVanButtonBox->setGeometry(QRect(20, 400, 341, 32));
        addCVanButtonBox->setOrientation(Qt::Horizontal);
        addCVanButtonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);
        layoutWidget_10 = new QWidget(addCVanDialog);
        layoutWidget_10->setObjectName(QStringLiteral("layoutWidget_10"));
        layoutWidget_10->setGeometry(QRect(10, 30, 351, 341));
        verticalLayout_18 = new QVBoxLayout(layoutWidget_10);
        verticalLayout_18->setObjectName(QStringLiteral("verticalLayout_18"));
        verticalLayout_18->setContentsMargins(0, 0, 0, 0);
        label_49 = new QLabel(layoutWidget_10);
        label_49->setObjectName(QStringLiteral("label_49"));

        verticalLayout_18->addWidget(label_49);

        model_CV = new QLineEdit(layoutWidget_10);
        model_CV->setObjectName(QStringLiteral("model_CV"));

        verticalLayout_18->addWidget(model_CV);

        label_50 = new QLabel(layoutWidget_10);
        label_50->setObjectName(QStringLiteral("label_50"));

        verticalLayout_18->addWidget(label_50);

        licnr_CV = new QLineEdit(layoutWidget_10);
        licnr_CV->setObjectName(QStringLiteral("licnr_CV"));

        verticalLayout_18->addWidget(licnr_CV);

        label_51 = new QLabel(layoutWidget_10);
        label_51->setObjectName(QStringLiteral("label_51"));

        verticalLayout_18->addWidget(label_51);

        comname_CV = new QLineEdit(layoutWidget_10);
        comname_CV->setObjectName(QStringLiteral("comname_CV"));

        verticalLayout_18->addWidget(comname_CV);

        label_52 = new QLabel(layoutWidget_10);
        label_52->setObjectName(QStringLiteral("label_52"));

        verticalLayout_18->addWidget(label_52);

        orgnr_CV = new QLineEdit(layoutWidget_10);
        orgnr_CV->setObjectName(QStringLiteral("orgnr_CV"));

        verticalLayout_18->addWidget(orgnr_CV);

        label_54 = new QLabel(layoutWidget_10);
        label_54->setObjectName(QStringLiteral("label_54"));

        verticalLayout_18->addWidget(label_54);

        loacap_CV = new QSpinBox(layoutWidget_10);
        loacap_CV->setObjectName(QStringLiteral("loacap_CV"));
        loacap_CV->setMaximum(99999);

        verticalLayout_18->addWidget(loacap_CV);


        retranslateUi(addCVanDialog);
        QObject::connect(addCVanButtonBox, SIGNAL(accepted()), addCVanDialog, SLOT(accept()));
        QObject::connect(addCVanButtonBox, SIGNAL(rejected()), addCVanDialog, SLOT(reject()));

        QMetaObject::connectSlotsByName(addCVanDialog);
    } // setupUi

    void retranslateUi(QDialog *addCVanDialog)
    {
        addCVanDialog->setWindowTitle(QApplication::translate("addCVanDialog", "Add company van", Q_NULLPTR));
        label_49->setText(QApplication::translate("addCVanDialog", "Model:", Q_NULLPTR));
        label_50->setText(QApplication::translate("addCVanDialog", "License Number:", Q_NULLPTR));
        label_51->setText(QApplication::translate("addCVanDialog", "Company Name:", Q_NULLPTR));
        label_52->setText(QApplication::translate("addCVanDialog", "Organization Number:", Q_NULLPTR));
        label_54->setText(QApplication::translate("addCVanDialog", "Load Capacity:", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class addCVanDialog: public Ui_addCVanDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ADDCVANDIALOG_H
