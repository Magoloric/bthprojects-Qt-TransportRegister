/********************************************************************************
** Form generated from reading UI file 'editbusdialog.ui'
**
** Created by: Qt User Interface Compiler version 5.8.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_EDITBUSDIALOG_H
#define UI_EDITBUSDIALOG_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QDialogButtonBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_editBusDialog
{
public:
    QDialogButtonBox *buttonBox;
    QWidget *layoutWidget_11;
    QVBoxLayout *verticalLayout_19;
    QLabel *label_55;
    QLineEdit *model_B;
    QLabel *label_57;
    QLineEdit *comname_B;
    QLabel *label_58;
    QLineEdit *orgnr_B;
    QLabel *label_59;
    QLineEdit *bustyp;
    QLabel *label_60;
    QSpinBox *insnr;
    QLabel *label_62;
    QSpinBox *nrofsea;

    void setupUi(QDialog *editBusDialog)
    {
        if (editBusDialog->objectName().isEmpty())
            editBusDialog->setObjectName(QStringLiteral("editBusDialog"));
        editBusDialog->resize(366, 465);
        buttonBox = new QDialogButtonBox(editBusDialog);
        buttonBox->setObjectName(QStringLiteral("buttonBox"));
        buttonBox->setGeometry(QRect(120, 410, 221, 32));
        buttonBox->setOrientation(Qt::Horizontal);
        buttonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);
        layoutWidget_11 = new QWidget(editBusDialog);
        layoutWidget_11->setObjectName(QStringLiteral("layoutWidget_11"));
        layoutWidget_11->setGeometry(QRect(20, 20, 321, 381));
        verticalLayout_19 = new QVBoxLayout(layoutWidget_11);
        verticalLayout_19->setObjectName(QStringLiteral("verticalLayout_19"));
        verticalLayout_19->setContentsMargins(0, 0, 0, 0);
        label_55 = new QLabel(layoutWidget_11);
        label_55->setObjectName(QStringLiteral("label_55"));

        verticalLayout_19->addWidget(label_55);

        model_B = new QLineEdit(layoutWidget_11);
        model_B->setObjectName(QStringLiteral("model_B"));

        verticalLayout_19->addWidget(model_B);

        label_57 = new QLabel(layoutWidget_11);
        label_57->setObjectName(QStringLiteral("label_57"));

        verticalLayout_19->addWidget(label_57);

        comname_B = new QLineEdit(layoutWidget_11);
        comname_B->setObjectName(QStringLiteral("comname_B"));

        verticalLayout_19->addWidget(comname_B);

        label_58 = new QLabel(layoutWidget_11);
        label_58->setObjectName(QStringLiteral("label_58"));

        verticalLayout_19->addWidget(label_58);

        orgnr_B = new QLineEdit(layoutWidget_11);
        orgnr_B->setObjectName(QStringLiteral("orgnr_B"));

        verticalLayout_19->addWidget(orgnr_B);

        label_59 = new QLabel(layoutWidget_11);
        label_59->setObjectName(QStringLiteral("label_59"));

        verticalLayout_19->addWidget(label_59);

        bustyp = new QLineEdit(layoutWidget_11);
        bustyp->setObjectName(QStringLiteral("bustyp"));

        verticalLayout_19->addWidget(bustyp);

        label_60 = new QLabel(layoutWidget_11);
        label_60->setObjectName(QStringLiteral("label_60"));

        verticalLayout_19->addWidget(label_60);

        insnr = new QSpinBox(layoutWidget_11);
        insnr->setObjectName(QStringLiteral("insnr"));
        insnr->setMaximum(999999);

        verticalLayout_19->addWidget(insnr);

        label_62 = new QLabel(layoutWidget_11);
        label_62->setObjectName(QStringLiteral("label_62"));

        verticalLayout_19->addWidget(label_62);

        nrofsea = new QSpinBox(layoutWidget_11);
        nrofsea->setObjectName(QStringLiteral("nrofsea"));
        nrofsea->setMaximum(200);

        verticalLayout_19->addWidget(nrofsea);


        retranslateUi(editBusDialog);
        QObject::connect(buttonBox, SIGNAL(accepted()), editBusDialog, SLOT(accept()));
        QObject::connect(buttonBox, SIGNAL(rejected()), editBusDialog, SLOT(reject()));

        QMetaObject::connectSlotsByName(editBusDialog);
    } // setupUi

    void retranslateUi(QDialog *editBusDialog)
    {
        editBusDialog->setWindowTitle(QApplication::translate("editBusDialog", "Edit bus", Q_NULLPTR));
        label_55->setText(QApplication::translate("editBusDialog", "Model:", Q_NULLPTR));
        label_57->setText(QApplication::translate("editBusDialog", "Company Name:", Q_NULLPTR));
        label_58->setText(QApplication::translate("editBusDialog", "Organization Number:", Q_NULLPTR));
        label_59->setText(QApplication::translate("editBusDialog", "Bus type:", Q_NULLPTR));
        label_60->setText(QApplication::translate("editBusDialog", "Inside Number:", Q_NULLPTR));
        label_62->setText(QApplication::translate("editBusDialog", "Number of seats:", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class editBusDialog: public Ui_editBusDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_EDITBUSDIALOG_H
