/********************************************************************************
** Form generated from reading UI file 'addccardialog.ui'
**
** Created by: Qt User Interface Compiler version 5.8.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ADDCCARDIALOG_H
#define UI_ADDCCARDIALOG_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QDialogButtonBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_addCCarDialog
{
public:
    QDialogButtonBox *addCCarButtonBox;
    QWidget *layoutWidget_13;
    QVBoxLayout *verticalLayout_21;
    QLabel *label_47;
    QLineEdit *model_CC_2;
    QLabel *label_53;
    QLineEdit *licnr_CC_2;
    QLabel *label_61;
    QLineEdit *comname_CC_2;
    QLabel *label_63;
    QLineEdit *orgnr_CC_2;
    QLabel *label_64;
    QLineEdit *ensur_CC_2;

    void setupUi(QDialog *addCCarDialog)
    {
        if (addCCarDialog->objectName().isEmpty())
            addCCarDialog->setObjectName(QStringLiteral("addCCarDialog"));
        addCCarDialog->resize(423, 486);
        addCCarButtonBox = new QDialogButtonBox(addCCarDialog);
        addCCarButtonBox->setObjectName(QStringLiteral("addCCarButtonBox"));
        addCCarButtonBox->setGeometry(QRect(70, 420, 341, 32));
        addCCarButtonBox->setOrientation(Qt::Horizontal);
        addCCarButtonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);
        layoutWidget_13 = new QWidget(addCCarDialog);
        layoutWidget_13->setObjectName(QStringLiteral("layoutWidget_13"));
        layoutWidget_13->setGeometry(QRect(10, 10, 401, 391));
        verticalLayout_21 = new QVBoxLayout(layoutWidget_13);
        verticalLayout_21->setObjectName(QStringLiteral("verticalLayout_21"));
        verticalLayout_21->setContentsMargins(0, 0, 0, 0);
        label_47 = new QLabel(layoutWidget_13);
        label_47->setObjectName(QStringLiteral("label_47"));

        verticalLayout_21->addWidget(label_47);

        model_CC_2 = new QLineEdit(layoutWidget_13);
        model_CC_2->setObjectName(QStringLiteral("model_CC_2"));

        verticalLayout_21->addWidget(model_CC_2);

        label_53 = new QLabel(layoutWidget_13);
        label_53->setObjectName(QStringLiteral("label_53"));

        verticalLayout_21->addWidget(label_53);

        licnr_CC_2 = new QLineEdit(layoutWidget_13);
        licnr_CC_2->setObjectName(QStringLiteral("licnr_CC_2"));

        verticalLayout_21->addWidget(licnr_CC_2);

        label_61 = new QLabel(layoutWidget_13);
        label_61->setObjectName(QStringLiteral("label_61"));

        verticalLayout_21->addWidget(label_61);

        comname_CC_2 = new QLineEdit(layoutWidget_13);
        comname_CC_2->setObjectName(QStringLiteral("comname_CC_2"));

        verticalLayout_21->addWidget(comname_CC_2);

        label_63 = new QLabel(layoutWidget_13);
        label_63->setObjectName(QStringLiteral("label_63"));

        verticalLayout_21->addWidget(label_63);

        orgnr_CC_2 = new QLineEdit(layoutWidget_13);
        orgnr_CC_2->setObjectName(QStringLiteral("orgnr_CC_2"));

        verticalLayout_21->addWidget(orgnr_CC_2);

        label_64 = new QLabel(layoutWidget_13);
        label_64->setObjectName(QStringLiteral("label_64"));

        verticalLayout_21->addWidget(label_64);

        ensur_CC_2 = new QLineEdit(layoutWidget_13);
        ensur_CC_2->setObjectName(QStringLiteral("ensur_CC_2"));

        verticalLayout_21->addWidget(ensur_CC_2);


        retranslateUi(addCCarDialog);
        QObject::connect(addCCarButtonBox, SIGNAL(accepted()), addCCarDialog, SLOT(accept()));
        QObject::connect(addCCarButtonBox, SIGNAL(rejected()), addCCarDialog, SLOT(reject()));

        QMetaObject::connectSlotsByName(addCCarDialog);
    } // setupUi

    void retranslateUi(QDialog *addCCarDialog)
    {
        addCCarDialog->setWindowTitle(QApplication::translate("addCCarDialog", "Add company car", Q_NULLPTR));
        label_47->setText(QApplication::translate("addCCarDialog", "Model:", Q_NULLPTR));
        label_53->setText(QApplication::translate("addCCarDialog", "License Number:", Q_NULLPTR));
        label_61->setText(QApplication::translate("addCCarDialog", "Company Name", Q_NULLPTR));
        label_63->setText(QApplication::translate("addCCarDialog", "Organization Number:", Q_NULLPTR));
        label_64->setText(QApplication::translate("addCCarDialog", "Ensured by:", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class addCCarDialog: public Ui_addCCarDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ADDCCARDIALOG_H
