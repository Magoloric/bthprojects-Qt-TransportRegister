/********************************************************************************
** Form generated from reading UI file 'editpvandialog.ui'
**
** Created by: Qt User Interface Compiler version 5.8.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_EDITPVANDIALOG_H
#define UI_EDITPVANDIALOG_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QDialogButtonBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_editpvandialog
{
public:
    QDialogButtonBox *buttonBox;
    QWidget *layoutWidget_3;
    QVBoxLayout *verticalLayout_11;
    QLabel *label_31;
    QLineEdit *model_PV;
    QLabel *label_33;
    QLineEdit *owname_PV;
    QLabel *label_34;
    QLineEdit *ownsur_PV;
    QLabel *label_35;
    QLineEdit *ownid_PV;
    QLabel *label_36;
    QSpinBox *locap_PV;

    void setupUi(QDialog *editpvandialog)
    {
        if (editpvandialog->objectName().isEmpty())
            editpvandialog->setObjectName(QStringLiteral("editpvandialog"));
        editpvandialog->resize(525, 395);
        buttonBox = new QDialogButtonBox(editpvandialog);
        buttonBox->setObjectName(QStringLiteral("buttonBox"));
        buttonBox->setGeometry(QRect(-10, 330, 341, 32));
        buttonBox->setOrientation(Qt::Horizontal);
        buttonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);
        layoutWidget_3 = new QWidget(editpvandialog);
        layoutWidget_3->setObjectName(QStringLiteral("layoutWidget_3"));
        layoutWidget_3->setGeometry(QRect(20, 20, 481, 291));
        verticalLayout_11 = new QVBoxLayout(layoutWidget_3);
        verticalLayout_11->setObjectName(QStringLiteral("verticalLayout_11"));
        verticalLayout_11->setContentsMargins(0, 0, 0, 0);
        label_31 = new QLabel(layoutWidget_3);
        label_31->setObjectName(QStringLiteral("label_31"));

        verticalLayout_11->addWidget(label_31);

        model_PV = new QLineEdit(layoutWidget_3);
        model_PV->setObjectName(QStringLiteral("model_PV"));

        verticalLayout_11->addWidget(model_PV);

        label_33 = new QLabel(layoutWidget_3);
        label_33->setObjectName(QStringLiteral("label_33"));

        verticalLayout_11->addWidget(label_33);

        owname_PV = new QLineEdit(layoutWidget_3);
        owname_PV->setObjectName(QStringLiteral("owname_PV"));

        verticalLayout_11->addWidget(owname_PV);

        label_34 = new QLabel(layoutWidget_3);
        label_34->setObjectName(QStringLiteral("label_34"));

        verticalLayout_11->addWidget(label_34);

        ownsur_PV = new QLineEdit(layoutWidget_3);
        ownsur_PV->setObjectName(QStringLiteral("ownsur_PV"));

        verticalLayout_11->addWidget(ownsur_PV);

        label_35 = new QLabel(layoutWidget_3);
        label_35->setObjectName(QStringLiteral("label_35"));

        verticalLayout_11->addWidget(label_35);

        ownid_PV = new QLineEdit(layoutWidget_3);
        ownid_PV->setObjectName(QStringLiteral("ownid_PV"));

        verticalLayout_11->addWidget(ownid_PV);

        label_36 = new QLabel(layoutWidget_3);
        label_36->setObjectName(QStringLiteral("label_36"));

        verticalLayout_11->addWidget(label_36);

        locap_PV = new QSpinBox(layoutWidget_3);
        locap_PV->setObjectName(QStringLiteral("locap_PV"));
        locap_PV->setMaximum(99999);

        verticalLayout_11->addWidget(locap_PV);


        retranslateUi(editpvandialog);
        QObject::connect(buttonBox, SIGNAL(accepted()), editpvandialog, SLOT(accept()));
        QObject::connect(buttonBox, SIGNAL(rejected()), editpvandialog, SLOT(reject()));

        QMetaObject::connectSlotsByName(editpvandialog);
    } // setupUi

    void retranslateUi(QDialog *editpvandialog)
    {
        editpvandialog->setWindowTitle(QApplication::translate("editpvandialog", "Edit private van", Q_NULLPTR));
        label_31->setText(QApplication::translate("editpvandialog", "Model:", Q_NULLPTR));
        label_33->setText(QApplication::translate("editpvandialog", "Owner Name:", Q_NULLPTR));
        label_34->setText(QApplication::translate("editpvandialog", "Owner Surname:", Q_NULLPTR));
        label_35->setText(QApplication::translate("editpvandialog", "Owner Civic ID:", Q_NULLPTR));
        label_36->setText(QApplication::translate("editpvandialog", "Load capacity:", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class editpvandialog: public Ui_editpvandialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_EDITPVANDIALOG_H
