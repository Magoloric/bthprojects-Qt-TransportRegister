/********************************************************************************
** Form generated from reading UI file 'fileexport.ui'
**
** Created by: Qt User Interface Compiler version 5.8.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_FILEEXPORT_H
#define UI_FILEEXPORT_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QDialogButtonBox>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_fileexport
{
public:
    QDialogButtonBox *exportButtons;
    QComboBox *whatToExport;
    QLabel *label;
    QWidget *layoutWidget;
    QGridLayout *gridLayout;
    QRadioButton *sortByLoadCap;
    QRadioButton *sortByModel;
    QRadioButton *sortByID;
    QRadioButton *sortByLicNr;
    QLabel *label_4;
    QLabel *label_5;
    QLabel *label_8;
    QLabel *label_9;
    QLabel *label_6;
    QRadioButton *sortByOrgNr;
    QLabel *label_3;
    QRadioButton *sortByOwName;
    QRadioButton *sortBySurname;
    QRadioButton *sortBySVol;
    QRadioButton *sortByBusType;
    QRadioButton *sortByEnsur;
    QRadioButton *sortByBusNumber;
    QRadioButton *sortByMaxSpeed;
    QRadioButton *sortByNrOfSeats;
    QLabel *label_7;
    QRadioButton *sortByCompName;
    QRadioButton *dontSortButton;

    void setupUi(QDialog *fileexport)
    {
        if (fileexport->objectName().isEmpty())
            fileexport->setObjectName(QStringLiteral("fileexport"));
        fileexport->resize(549, 417);
        exportButtons = new QDialogButtonBox(fileexport);
        exportButtons->setObjectName(QStringLiteral("exportButtons"));
        exportButtons->setGeometry(QRect(150, 360, 361, 51));
        exportButtons->setOrientation(Qt::Horizontal);
        exportButtons->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Save);
        whatToExport = new QComboBox(fileexport);
        whatToExport->setObjectName(QStringLiteral("whatToExport"));
        whatToExport->setGeometry(QRect(20, 30, 511, 31));
        label = new QLabel(fileexport);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(20, 10, 81, 21));
        layoutWidget = new QWidget(fileexport);
        layoutWidget->setObjectName(QStringLiteral("layoutWidget"));
        layoutWidget->setGeometry(QRect(20, 70, 521, 261));
        gridLayout = new QGridLayout(layoutWidget);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        gridLayout->setContentsMargins(0, 0, 0, 0);
        sortByLoadCap = new QRadioButton(layoutWidget);
        sortByLoadCap->setObjectName(QStringLiteral("sortByLoadCap"));

        gridLayout->addWidget(sortByLoadCap, 15, 0, 2, 1);

        sortByModel = new QRadioButton(layoutWidget);
        sortByModel->setObjectName(QStringLiteral("sortByModel"));

        gridLayout->addWidget(sortByModel, 3, 0, 2, 1);

        sortByID = new QRadioButton(layoutWidget);
        sortByID->setObjectName(QStringLiteral("sortByID"));

        gridLayout->addWidget(sortByID, 7, 1, 2, 1);

        sortByLicNr = new QRadioButton(layoutWidget);
        sortByLicNr->setObjectName(QStringLiteral("sortByLicNr"));

        gridLayout->addWidget(sortByLicNr, 5, 0, 2, 1);

        label_4 = new QLabel(layoutWidget);
        label_4->setObjectName(QStringLiteral("label_4"));

        gridLayout->addWidget(label_4, 1, 1, 2, 1);

        label_5 = new QLabel(layoutWidget);
        label_5->setObjectName(QStringLiteral("label_5"));

        gridLayout->addWidget(label_5, 1, 2, 2, 1);

        label_8 = new QLabel(layoutWidget);
        label_8->setObjectName(QStringLiteral("label_8"));

        gridLayout->addWidget(label_8, 9, 1, 2, 1);

        label_9 = new QLabel(layoutWidget);
        label_9->setObjectName(QStringLiteral("label_9"));

        gridLayout->addWidget(label_9, 9, 2, 2, 1);

        label_6 = new QLabel(layoutWidget);
        label_6->setObjectName(QStringLiteral("label_6"));

        gridLayout->addWidget(label_6, 9, 0, 2, 1);

        sortByOrgNr = new QRadioButton(layoutWidget);
        sortByOrgNr->setObjectName(QStringLiteral("sortByOrgNr"));

        gridLayout->addWidget(sortByOrgNr, 5, 2, 2, 1);

        label_3 = new QLabel(layoutWidget);
        label_3->setObjectName(QStringLiteral("label_3"));

        gridLayout->addWidget(label_3, 1, 0, 2, 1);

        sortByOwName = new QRadioButton(layoutWidget);
        sortByOwName->setObjectName(QStringLiteral("sortByOwName"));

        gridLayout->addWidget(sortByOwName, 3, 1, 2, 1);

        sortBySurname = new QRadioButton(layoutWidget);
        sortBySurname->setObjectName(QStringLiteral("sortBySurname"));

        gridLayout->addWidget(sortBySurname, 5, 1, 2, 1);

        sortBySVol = new QRadioButton(layoutWidget);
        sortBySVol->setObjectName(QStringLiteral("sortBySVol"));

        gridLayout->addWidget(sortBySVol, 14, 1, 3, 1);

        sortByBusType = new QRadioButton(layoutWidget);
        sortByBusType->setObjectName(QStringLiteral("sortByBusType"));

        gridLayout->addWidget(sortByBusType, 11, 2, 2, 1);

        sortByEnsur = new QRadioButton(layoutWidget);
        sortByEnsur->setObjectName(QStringLiteral("sortByEnsur"));

        gridLayout->addWidget(sortByEnsur, 11, 0, 2, 1);

        sortByBusNumber = new QRadioButton(layoutWidget);
        sortByBusNumber->setObjectName(QStringLiteral("sortByBusNumber"));

        gridLayout->addWidget(sortByBusNumber, 13, 2, 2, 1);

        sortByMaxSpeed = new QRadioButton(layoutWidget);
        sortByMaxSpeed->setObjectName(QStringLiteral("sortByMaxSpeed"));

        gridLayout->addWidget(sortByMaxSpeed, 11, 1, 3, 1);

        sortByNrOfSeats = new QRadioButton(layoutWidget);
        sortByNrOfSeats->setObjectName(QStringLiteral("sortByNrOfSeats"));

        gridLayout->addWidget(sortByNrOfSeats, 15, 2, 2, 1);

        label_7 = new QLabel(layoutWidget);
        label_7->setObjectName(QStringLiteral("label_7"));

        gridLayout->addWidget(label_7, 13, 0, 2, 1);

        sortByCompName = new QRadioButton(layoutWidget);
        sortByCompName->setObjectName(QStringLiteral("sortByCompName"));

        gridLayout->addWidget(sortByCompName, 3, 2, 2, 1);

        dontSortButton = new QRadioButton(layoutWidget);
        dontSortButton->setObjectName(QStringLiteral("dontSortButton"));

        gridLayout->addWidget(dontSortButton, 0, 0, 1, 1);


        retranslateUi(fileexport);
        QObject::connect(exportButtons, SIGNAL(accepted()), fileexport, SLOT(accept()));
        QObject::connect(exportButtons, SIGNAL(rejected()), fileexport, SLOT(reject()));

        QMetaObject::connectSlotsByName(fileexport);
    } // setupUi

    void retranslateUi(QDialog *fileexport)
    {
        fileexport->setWindowTitle(QApplication::translate("fileexport", "Dialog", Q_NULLPTR));
        whatToExport->clear();
        whatToExport->insertItems(0, QStringList()
         << QApplication::translate("fileexport", "All vehicles", Q_NULLPTR)
         << QApplication::translate("fileexport", "Private cars", Q_NULLPTR)
         << QApplication::translate("fileexport", "Private vans", Q_NULLPTR)
         << QApplication::translate("fileexport", "Motorbikes", Q_NULLPTR)
         << QApplication::translate("fileexport", "Company cars", Q_NULLPTR)
         << QApplication::translate("fileexport", "Company vans", Q_NULLPTR)
         << QApplication::translate("fileexport", "Buses", Q_NULLPTR)
        );
        label->setText(QApplication::translate("fileexport", "Export:", Q_NULLPTR));
        sortByLoadCap->setText(QApplication::translate("fileexport", "Load capacity", Q_NULLPTR));
        sortByModel->setText(QApplication::translate("fileexport", "Model", Q_NULLPTR));
        sortByID->setText(QApplication::translate("fileexport", "Owner ID", Q_NULLPTR));
        sortByLicNr->setText(QApplication::translate("fileexport", "License number", Q_NULLPTR));
        label_4->setText(QApplication::translate("fileexport", "Private vehicles", Q_NULLPTR));
        label_5->setText(QApplication::translate("fileexport", "Company vehicles", Q_NULLPTR));
        label_8->setText(QApplication::translate("fileexport", "Motorbike-specific", Q_NULLPTR));
        label_9->setText(QApplication::translate("fileexport", "Bus-specific", Q_NULLPTR));
        label_6->setText(QApplication::translate("fileexport", "Car-specific", Q_NULLPTR));
        sortByOrgNr->setText(QApplication::translate("fileexport", "Org. number", Q_NULLPTR));
        label_3->setText(QApplication::translate("fileexport", "General", Q_NULLPTR));
        sortByOwName->setText(QApplication::translate("fileexport", "Owner Name", Q_NULLPTR));
        sortBySurname->setText(QApplication::translate("fileexport", "Owner surname", Q_NULLPTR));
        sortBySVol->setText(QApplication::translate("fileexport", "Swept volume", Q_NULLPTR));
        sortByBusType->setText(QApplication::translate("fileexport", "Bus type", Q_NULLPTR));
        sortByEnsur->setText(QApplication::translate("fileexport", "Ensurance", Q_NULLPTR));
        sortByBusNumber->setText(QApplication::translate("fileexport", "Bus number", Q_NULLPTR));
        sortByMaxSpeed->setText(QApplication::translate("fileexport", "Max. speed", Q_NULLPTR));
        sortByNrOfSeats->setText(QApplication::translate("fileexport", "Number of seats", Q_NULLPTR));
        label_7->setText(QApplication::translate("fileexport", "Van-specific", Q_NULLPTR));
        sortByCompName->setText(QApplication::translate("fileexport", "Company name", Q_NULLPTR));
        dontSortButton->setText(QApplication::translate("fileexport", "Do not sort", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class fileexport: public Ui_fileexport {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_FILEEXPORT_H
