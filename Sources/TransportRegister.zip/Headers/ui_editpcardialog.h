/********************************************************************************
** Form generated from reading UI file 'editpcardialog.ui'
**
** Created by: Qt User Interface Compiler version 5.8.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_EDITPCARDIALOG_H
#define UI_EDITPCARDIALOG_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QDialogButtonBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_editPCarDialog
{
public:
    QDialogButtonBox *EditPCarBbuttonBox;
    QWidget *layoutWidget_2;
    QVBoxLayout *verticalLayout_4;
    QLabel *label_71;
    QLineEdit *modl4;
    QLabel *label_9;
    QLineEdit *owNa4;
    QLabel *label_101;
    QLineEdit *owSu4;
    QLabel *label_111;
    QLineEdit *owID4;
    QLabel *label_121;
    QLineEdit *ensu4;

    void setupUi(QDialog *editPCarDialog)
    {
        if (editPCarDialog->objectName().isEmpty())
            editPCarDialog->setObjectName(QStringLiteral("editPCarDialog"));
        editPCarDialog->resize(382, 337);
        EditPCarBbuttonBox = new QDialogButtonBox(editPCarDialog);
        EditPCarBbuttonBox->setObjectName(QStringLiteral("EditPCarBbuttonBox"));
        EditPCarBbuttonBox->setGeometry(QRect(20, 290, 341, 32));
        EditPCarBbuttonBox->setOrientation(Qt::Horizontal);
        EditPCarBbuttonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);
        layoutWidget_2 = new QWidget(editPCarDialog);
        layoutWidget_2->setObjectName(QStringLiteral("layoutWidget_2"));
        layoutWidget_2->setGeometry(QRect(10, 10, 351, 271));
        verticalLayout_4 = new QVBoxLayout(layoutWidget_2);
        verticalLayout_4->setObjectName(QStringLiteral("verticalLayout_4"));
        verticalLayout_4->setContentsMargins(0, 0, 0, 0);
        label_71 = new QLabel(layoutWidget_2);
        label_71->setObjectName(QStringLiteral("label_71"));

        verticalLayout_4->addWidget(label_71);

        modl4 = new QLineEdit(layoutWidget_2);
        modl4->setObjectName(QStringLiteral("modl4"));

        verticalLayout_4->addWidget(modl4);

        label_9 = new QLabel(layoutWidget_2);
        label_9->setObjectName(QStringLiteral("label_9"));

        verticalLayout_4->addWidget(label_9);

        owNa4 = new QLineEdit(layoutWidget_2);
        owNa4->setObjectName(QStringLiteral("owNa4"));

        verticalLayout_4->addWidget(owNa4);

        label_101 = new QLabel(layoutWidget_2);
        label_101->setObjectName(QStringLiteral("label_101"));

        verticalLayout_4->addWidget(label_101);

        owSu4 = new QLineEdit(layoutWidget_2);
        owSu4->setObjectName(QStringLiteral("owSu4"));

        verticalLayout_4->addWidget(owSu4);

        label_111 = new QLabel(layoutWidget_2);
        label_111->setObjectName(QStringLiteral("label_111"));

        verticalLayout_4->addWidget(label_111);

        owID4 = new QLineEdit(layoutWidget_2);
        owID4->setObjectName(QStringLiteral("owID4"));

        verticalLayout_4->addWidget(owID4);

        label_121 = new QLabel(layoutWidget_2);
        label_121->setObjectName(QStringLiteral("label_121"));

        verticalLayout_4->addWidget(label_121);

        ensu4 = new QLineEdit(layoutWidget_2);
        ensu4->setObjectName(QStringLiteral("ensu4"));

        verticalLayout_4->addWidget(ensu4);


        retranslateUi(editPCarDialog);
        QObject::connect(EditPCarBbuttonBox, SIGNAL(accepted()), editPCarDialog, SLOT(accept()));
        QObject::connect(EditPCarBbuttonBox, SIGNAL(rejected()), editPCarDialog, SLOT(reject()));

        QMetaObject::connectSlotsByName(editPCarDialog);
    } // setupUi

    void retranslateUi(QDialog *editPCarDialog)
    {
        editPCarDialog->setWindowTitle(QApplication::translate("editPCarDialog", "Edit private car", Q_NULLPTR));
        label_71->setText(QApplication::translate("editPCarDialog", "Model:", Q_NULLPTR));
        label_9->setText(QApplication::translate("editPCarDialog", "Owner Name:", Q_NULLPTR));
        label_101->setText(QApplication::translate("editPCarDialog", "Owner Surname:", Q_NULLPTR));
        label_111->setText(QApplication::translate("editPCarDialog", "Owner Civic ID:", Q_NULLPTR));
        label_121->setText(QApplication::translate("editPCarDialog", "Ensured by:", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class editPCarDialog: public Ui_editPCarDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_EDITPCARDIALOG_H
