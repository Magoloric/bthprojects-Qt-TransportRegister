/********************************************************************************
** Form generated from reading UI file 'editcvandialog.ui'
**
** Created by: Qt User Interface Compiler version 5.8.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_EDITCVANDIALOG_H
#define UI_EDITCVANDIALOG_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QDialogButtonBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_editCVanDialog
{
public:
    QDialogButtonBox *buttonBox;
    QWidget *layoutWidget_9;
    QVBoxLayout *verticalLayout_17;
    QLabel *label_49;
    QLineEdit *model_CV;
    QLabel *label_51;
    QLineEdit *comname_CV;
    QLabel *label_52;
    QLineEdit *orgnr_CV;
    QLabel *label_54;
    QSpinBox *loacap_CV;

    void setupUi(QDialog *editCVanDialog)
    {
        if (editCVanDialog->objectName().isEmpty())
            editCVanDialog->setObjectName(QStringLiteral("editCVanDialog"));
        editCVanDialog->resize(388, 312);
        buttonBox = new QDialogButtonBox(editCVanDialog);
        buttonBox->setObjectName(QStringLiteral("buttonBox"));
        buttonBox->setGeometry(QRect(30, 260, 341, 32));
        buttonBox->setOrientation(Qt::Horizontal);
        buttonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);
        layoutWidget_9 = new QWidget(editCVanDialog);
        layoutWidget_9->setObjectName(QStringLiteral("layoutWidget_9"));
        layoutWidget_9->setGeometry(QRect(10, 20, 361, 231));
        verticalLayout_17 = new QVBoxLayout(layoutWidget_9);
        verticalLayout_17->setObjectName(QStringLiteral("verticalLayout_17"));
        verticalLayout_17->setContentsMargins(0, 0, 0, 0);
        label_49 = new QLabel(layoutWidget_9);
        label_49->setObjectName(QStringLiteral("label_49"));

        verticalLayout_17->addWidget(label_49);

        model_CV = new QLineEdit(layoutWidget_9);
        model_CV->setObjectName(QStringLiteral("model_CV"));

        verticalLayout_17->addWidget(model_CV);

        label_51 = new QLabel(layoutWidget_9);
        label_51->setObjectName(QStringLiteral("label_51"));

        verticalLayout_17->addWidget(label_51);

        comname_CV = new QLineEdit(layoutWidget_9);
        comname_CV->setObjectName(QStringLiteral("comname_CV"));

        verticalLayout_17->addWidget(comname_CV);

        label_52 = new QLabel(layoutWidget_9);
        label_52->setObjectName(QStringLiteral("label_52"));

        verticalLayout_17->addWidget(label_52);

        orgnr_CV = new QLineEdit(layoutWidget_9);
        orgnr_CV->setObjectName(QStringLiteral("orgnr_CV"));

        verticalLayout_17->addWidget(orgnr_CV);

        label_54 = new QLabel(layoutWidget_9);
        label_54->setObjectName(QStringLiteral("label_54"));

        verticalLayout_17->addWidget(label_54);

        loacap_CV = new QSpinBox(layoutWidget_9);
        loacap_CV->setObjectName(QStringLiteral("loacap_CV"));
        loacap_CV->setMaximum(999999);

        verticalLayout_17->addWidget(loacap_CV);


        retranslateUi(editCVanDialog);
        QObject::connect(buttonBox, SIGNAL(accepted()), editCVanDialog, SLOT(accept()));
        QObject::connect(buttonBox, SIGNAL(rejected()), editCVanDialog, SLOT(reject()));

        QMetaObject::connectSlotsByName(editCVanDialog);
    } // setupUi

    void retranslateUi(QDialog *editCVanDialog)
    {
        editCVanDialog->setWindowTitle(QApplication::translate("editCVanDialog", "Edit company van", Q_NULLPTR));
        label_49->setText(QApplication::translate("editCVanDialog", "Model:", Q_NULLPTR));
        label_51->setText(QApplication::translate("editCVanDialog", "Company Name:", Q_NULLPTR));
        label_52->setText(QApplication::translate("editCVanDialog", "Organization Number:", Q_NULLPTR));
        label_54->setText(QApplication::translate("editCVanDialog", "Load Capacity:", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class editCVanDialog: public Ui_editCVanDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_EDITCVANDIALOG_H
