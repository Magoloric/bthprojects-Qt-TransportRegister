/********************************************************************************
** Form generated from reading UI file 'transportregisterwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.8.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_TRANSPORTREGISTERWINDOW_H
#define UI_TRANSPORTREGISTERWINDOW_H

#include <QtCore/QLocale>
#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QTableView>
#include <QtWidgets/QTextBrowser>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_TransportRegisterWindow
{
public:
    QAction *actionExport;
    QAction *actionImport;
    QWidget *centralWidget;
    QTabWidget *tabsy;
    QWidget *PCTab;
    QTableView *PCarView;
    QPushButton *addPCarButton;
    QWidget *PVTab;
    QTableView *PVanView;
    QPushButton *addPVanButton;
    QWidget *MBTab;
    QTableView *MBikeView;
    QPushButton *addMBikeButton;
    QWidget *CCTab;
    QTableView *CCarView;
    QPushButton *addCCarButton;
    QWidget *CVTab;
    QTableView *CVanView;
    QPushButton *addCVanButton;
    QWidget *BTab;
    QTableView *BusView;
    QPushButton *addBusButton;
    QWidget *searchTab;
    QTableView *searchView;
    QLineEdit *lineEdit;
    QLabel *label;
    QPushButton *searchButton;
    QWidget *layoutWidget;
    QGridLayout *gridLayout_2;
    QRadioButton *allButton;
    QRadioButton *pCarsButton;
    QRadioButton *pVanButton;
    QRadioButton *mBikeButton;
    QRadioButton *cCarButton;
    QRadioButton *cVanButton;
    QRadioButton *busButton;
    QWidget *layoutWidget1;
    QVBoxLayout *verticalLayout;
    QTextBrowser *infoView;
    QGridLayout *gridLayout;
    QPushButton *importButton;
    QPushButton *exportButton;
    QPushButton *removeButton;
    QPushButton *openButton;
    QPushButton *aboutButton;
    QPushButton *quitButton;
    QPushButton *logoutButton;
    QPushButton *clearButton;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *TransportRegisterWindow)
    {
        if (TransportRegisterWindow->objectName().isEmpty())
            TransportRegisterWindow->setObjectName(QStringLiteral("TransportRegisterWindow"));
        TransportRegisterWindow->resize(1628, 528);
        actionExport = new QAction(TransportRegisterWindow);
        actionExport->setObjectName(QStringLiteral("actionExport"));
        actionImport = new QAction(TransportRegisterWindow);
        actionImport->setObjectName(QStringLiteral("actionImport"));
        centralWidget = new QWidget(TransportRegisterWindow);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        tabsy = new QTabWidget(centralWidget);
        tabsy->setObjectName(QStringLiteral("tabsy"));
        tabsy->setGeometry(QRect(10, 10, 1321, 461));
        tabsy->setLocale(QLocale(QLocale::Russian, QLocale::Russia));
        tabsy->setElideMode(Qt::ElideRight);
        PCTab = new QWidget();
        PCTab->setObjectName(QStringLiteral("PCTab"));
        PCTab->setAutoFillBackground(false);
        PCarView = new QTableView(PCTab);
        PCarView->setObjectName(QStringLiteral("PCarView"));
        PCarView->setGeometry(QRect(10, 10, 1291, 371));
        PCarView->setLocale(QLocale(QLocale::Russian, QLocale::Russia));
        PCarView->setEditTriggers(QAbstractItemView::NoEditTriggers);
        PCarView->setDragDropOverwriteMode(true);
        PCarView->setSelectionMode(QAbstractItemView::SingleSelection);
        PCarView->setSelectionBehavior(QAbstractItemView::SelectRows);
        PCarView->setSortingEnabled(true);
        PCarView->horizontalHeader()->setProperty("showSortIndicator", QVariant(true));
        PCarView->verticalHeader()->setVisible(false);
        addPCarButton = new QPushButton(PCTab);
        addPCarButton->setObjectName(QStringLiteral("addPCarButton"));
        addPCarButton->setGeometry(QRect(1180, 390, 121, 31));
        tabsy->addTab(PCTab, QString());
        PVTab = new QWidget();
        PVTab->setObjectName(QStringLiteral("PVTab"));
        PVanView = new QTableView(PVTab);
        PVanView->setObjectName(QStringLiteral("PVanView"));
        PVanView->setGeometry(QRect(10, 10, 1291, 371));
        PVanView->setLocale(QLocale(QLocale::Russian, QLocale::Russia));
        PVanView->setEditTriggers(QAbstractItemView::NoEditTriggers);
        PVanView->setDragDropOverwriteMode(false);
        PVanView->setSelectionBehavior(QAbstractItemView::SelectRows);
        addPVanButton = new QPushButton(PVTab);
        addPVanButton->setObjectName(QStringLiteral("addPVanButton"));
        addPVanButton->setGeometry(QRect(1180, 390, 121, 31));
        tabsy->addTab(PVTab, QString());
        MBTab = new QWidget();
        MBTab->setObjectName(QStringLiteral("MBTab"));
        MBikeView = new QTableView(MBTab);
        MBikeView->setObjectName(QStringLiteral("MBikeView"));
        MBikeView->setGeometry(QRect(10, 10, 1291, 371));
        MBikeView->setLocale(QLocale(QLocale::Russian, QLocale::Russia));
        MBikeView->setEditTriggers(QAbstractItemView::NoEditTriggers);
        addMBikeButton = new QPushButton(MBTab);
        addMBikeButton->setObjectName(QStringLiteral("addMBikeButton"));
        addMBikeButton->setGeometry(QRect(1180, 390, 121, 31));
        tabsy->addTab(MBTab, QString());
        CCTab = new QWidget();
        CCTab->setObjectName(QStringLiteral("CCTab"));
        CCarView = new QTableView(CCTab);
        CCarView->setObjectName(QStringLiteral("CCarView"));
        CCarView->setGeometry(QRect(10, 10, 1291, 371));
        CCarView->setLocale(QLocale(QLocale::Russian, QLocale::Russia));
        CCarView->setEditTriggers(QAbstractItemView::NoEditTriggers);
        addCCarButton = new QPushButton(CCTab);
        addCCarButton->setObjectName(QStringLiteral("addCCarButton"));
        addCCarButton->setGeometry(QRect(1180, 390, 121, 31));
        tabsy->addTab(CCTab, QString());
        CVTab = new QWidget();
        CVTab->setObjectName(QStringLiteral("CVTab"));
        CVanView = new QTableView(CVTab);
        CVanView->setObjectName(QStringLiteral("CVanView"));
        CVanView->setGeometry(QRect(10, 10, 1291, 371));
        CVanView->setLocale(QLocale(QLocale::Russian, QLocale::Russia));
        CVanView->setEditTriggers(QAbstractItemView::NoEditTriggers);
        addCVanButton = new QPushButton(CVTab);
        addCVanButton->setObjectName(QStringLiteral("addCVanButton"));
        addCVanButton->setGeometry(QRect(1180, 390, 121, 31));
        addCVanButton->setLocale(QLocale(QLocale::Russian, QLocale::Russia));
        tabsy->addTab(CVTab, QString());
        BTab = new QWidget();
        BTab->setObjectName(QStringLiteral("BTab"));
        BusView = new QTableView(BTab);
        BusView->setObjectName(QStringLiteral("BusView"));
        BusView->setGeometry(QRect(10, 10, 1291, 371));
        BusView->setLocale(QLocale(QLocale::Russian, QLocale::Russia));
        BusView->setEditTriggers(QAbstractItemView::NoEditTriggers);
        addBusButton = new QPushButton(BTab);
        addBusButton->setObjectName(QStringLiteral("addBusButton"));
        addBusButton->setGeometry(QRect(1180, 390, 121, 31));
        tabsy->addTab(BTab, QString());
        searchTab = new QWidget();
        searchTab->setObjectName(QStringLiteral("searchTab"));
        searchView = new QTableView(searchTab);
        searchView->setObjectName(QStringLiteral("searchView"));
        searchView->setGeometry(QRect(20, 110, 1281, 291));
        searchView->setSizeAdjustPolicy(QAbstractScrollArea::AdjustToContents);
        searchView->setEditTriggers(QAbstractItemView::NoEditTriggers);
        lineEdit = new QLineEdit(searchTab);
        lineEdit->setObjectName(QStringLiteral("lineEdit"));
        lineEdit->setGeometry(QRect(120, 30, 1041, 31));
        label = new QLabel(searchTab);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(20, 30, 91, 31));
        searchButton = new QPushButton(searchTab);
        searchButton->setObjectName(QStringLiteral("searchButton"));
        searchButton->setGeometry(QRect(1170, 30, 131, 31));
        layoutWidget = new QWidget(searchTab);
        layoutWidget->setObjectName(QStringLiteral("layoutWidget"));
        layoutWidget->setGeometry(QRect(120, 70, 1181, 31));
        gridLayout_2 = new QGridLayout(layoutWidget);
        gridLayout_2->setSpacing(6);
        gridLayout_2->setContentsMargins(11, 11, 11, 11);
        gridLayout_2->setObjectName(QStringLiteral("gridLayout_2"));
        gridLayout_2->setContentsMargins(0, 0, 0, 0);
        allButton = new QRadioButton(layoutWidget);
        allButton->setObjectName(QStringLiteral("allButton"));

        gridLayout_2->addWidget(allButton, 0, 0, 1, 1);

        pCarsButton = new QRadioButton(layoutWidget);
        pCarsButton->setObjectName(QStringLiteral("pCarsButton"));

        gridLayout_2->addWidget(pCarsButton, 0, 1, 1, 1);

        pVanButton = new QRadioButton(layoutWidget);
        pVanButton->setObjectName(QStringLiteral("pVanButton"));

        gridLayout_2->addWidget(pVanButton, 0, 2, 1, 1);

        mBikeButton = new QRadioButton(layoutWidget);
        mBikeButton->setObjectName(QStringLiteral("mBikeButton"));

        gridLayout_2->addWidget(mBikeButton, 0, 3, 1, 1);

        cCarButton = new QRadioButton(layoutWidget);
        cCarButton->setObjectName(QStringLiteral("cCarButton"));

        gridLayout_2->addWidget(cCarButton, 0, 4, 1, 1);

        cVanButton = new QRadioButton(layoutWidget);
        cVanButton->setObjectName(QStringLiteral("cVanButton"));

        gridLayout_2->addWidget(cVanButton, 0, 5, 1, 1);

        busButton = new QRadioButton(layoutWidget);
        busButton->setObjectName(QStringLiteral("busButton"));

        gridLayout_2->addWidget(busButton, 0, 6, 1, 1);

        tabsy->addTab(searchTab, QString());
        layoutWidget1 = new QWidget(centralWidget);
        layoutWidget1->setObjectName(QStringLiteral("layoutWidget1"));
        layoutWidget1->setGeometry(QRect(1357, 40, 251, 431));
        verticalLayout = new QVBoxLayout(layoutWidget1);
        verticalLayout->setSpacing(6);
        verticalLayout->setContentsMargins(11, 11, 11, 11);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        infoView = new QTextBrowser(layoutWidget1);
        infoView->setObjectName(QStringLiteral("infoView"));

        verticalLayout->addWidget(infoView);

        gridLayout = new QGridLayout();
        gridLayout->setSpacing(6);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        importButton = new QPushButton(layoutWidget1);
        importButton->setObjectName(QStringLiteral("importButton"));

        gridLayout->addWidget(importButton, 2, 0, 1, 1);

        exportButton = new QPushButton(layoutWidget1);
        exportButton->setObjectName(QStringLiteral("exportButton"));

        gridLayout->addWidget(exportButton, 2, 1, 1, 1);

        removeButton = new QPushButton(layoutWidget1);
        removeButton->setObjectName(QStringLiteral("removeButton"));

        gridLayout->addWidget(removeButton, 0, 1, 1, 1);

        openButton = new QPushButton(layoutWidget1);
        openButton->setObjectName(QStringLiteral("openButton"));

        gridLayout->addWidget(openButton, 0, 0, 1, 1);

        aboutButton = new QPushButton(layoutWidget1);
        aboutButton->setObjectName(QStringLiteral("aboutButton"));

        gridLayout->addWidget(aboutButton, 7, 0, 1, 1);

        quitButton = new QPushButton(layoutWidget1);
        quitButton->setObjectName(QStringLiteral("quitButton"));

        gridLayout->addWidget(quitButton, 7, 1, 1, 1);

        logoutButton = new QPushButton(layoutWidget1);
        logoutButton->setObjectName(QStringLiteral("logoutButton"));

        gridLayout->addWidget(logoutButton, 3, 1, 1, 1);

        clearButton = new QPushButton(layoutWidget1);
        clearButton->setObjectName(QStringLiteral("clearButton"));

        gridLayout->addWidget(clearButton, 3, 0, 1, 1);


        verticalLayout->addLayout(gridLayout);

        TransportRegisterWindow->setCentralWidget(centralWidget);
        mainToolBar = new QToolBar(TransportRegisterWindow);
        mainToolBar->setObjectName(QStringLiteral("mainToolBar"));
        TransportRegisterWindow->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(TransportRegisterWindow);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        TransportRegisterWindow->setStatusBar(statusBar);
        QWidget::setTabOrder(tabsy, PCarView);

        retranslateUi(TransportRegisterWindow);

        tabsy->setCurrentIndex(1);


        QMetaObject::connectSlotsByName(TransportRegisterWindow);
    } // setupUi

    void retranslateUi(QMainWindow *TransportRegisterWindow)
    {
        TransportRegisterWindow->setWindowTitle(QApplication::translate("TransportRegisterWindow", "Transport Register v.1.0", Q_NULLPTR));
        actionExport->setText(QApplication::translate("TransportRegisterWindow", "Export", Q_NULLPTR));
        actionImport->setText(QApplication::translate("TransportRegisterWindow", "Import", Q_NULLPTR));
#ifndef QT_NO_ACCESSIBILITY
        PCTab->setAccessibleName(QApplication::translate("TransportRegisterWindow", "Private car", Q_NULLPTR));
#endif // QT_NO_ACCESSIBILITY
        addPCarButton->setText(QApplication::translate("TransportRegisterWindow", "Add...", Q_NULLPTR));
        tabsy->setTabText(tabsy->indexOf(PCTab), QApplication::translate("TransportRegisterWindow", "Private Cars", Q_NULLPTR));
        addPVanButton->setText(QApplication::translate("TransportRegisterWindow", "Add...", Q_NULLPTR));
        tabsy->setTabText(tabsy->indexOf(PVTab), QApplication::translate("TransportRegisterWindow", "Private Vans", Q_NULLPTR));
        addMBikeButton->setText(QApplication::translate("TransportRegisterWindow", "Add...", Q_NULLPTR));
        tabsy->setTabText(tabsy->indexOf(MBTab), QApplication::translate("TransportRegisterWindow", "Motorbikes", Q_NULLPTR));
        addCCarButton->setText(QApplication::translate("TransportRegisterWindow", "Add...", Q_NULLPTR));
        tabsy->setTabText(tabsy->indexOf(CCTab), QApplication::translate("TransportRegisterWindow", "Company Cars", Q_NULLPTR));
        addCVanButton->setText(QApplication::translate("TransportRegisterWindow", "Add...", Q_NULLPTR));
        tabsy->setTabText(tabsy->indexOf(CVTab), QApplication::translate("TransportRegisterWindow", "Company Vans", Q_NULLPTR));
        addBusButton->setText(QApplication::translate("TransportRegisterWindow", "Add...", Q_NULLPTR));
        tabsy->setTabText(tabsy->indexOf(BTab), QApplication::translate("TransportRegisterWindow", "Buses", Q_NULLPTR));
        label->setText(QApplication::translate("TransportRegisterWindow", "Search:", Q_NULLPTR));
        searchButton->setText(QApplication::translate("TransportRegisterWindow", "Search", Q_NULLPTR));
        allButton->setText(QApplication::translate("TransportRegisterWindow", "All Vehicles", Q_NULLPTR));
        pCarsButton->setText(QApplication::translate("TransportRegisterWindow", "Private cars", Q_NULLPTR));
        pVanButton->setText(QApplication::translate("TransportRegisterWindow", "Private vans", Q_NULLPTR));
        mBikeButton->setText(QApplication::translate("TransportRegisterWindow", "Motorbikes", Q_NULLPTR));
        cCarButton->setText(QApplication::translate("TransportRegisterWindow", "Company cars", Q_NULLPTR));
        cVanButton->setText(QApplication::translate("TransportRegisterWindow", "Company vans", Q_NULLPTR));
        busButton->setText(QApplication::translate("TransportRegisterWindow", "Bus", Q_NULLPTR));
        tabsy->setTabText(tabsy->indexOf(searchTab), QApplication::translate("TransportRegisterWindow", "Search", Q_NULLPTR));
        importButton->setText(QApplication::translate("TransportRegisterWindow", "Import", Q_NULLPTR));
        exportButton->setText(QApplication::translate("TransportRegisterWindow", "Export", Q_NULLPTR));
        removeButton->setText(QApplication::translate("TransportRegisterWindow", "Remove...", Q_NULLPTR));
        openButton->setText(QApplication::translate("TransportRegisterWindow", "Open", Q_NULLPTR));
        aboutButton->setText(QApplication::translate("TransportRegisterWindow", "About", Q_NULLPTR));
        quitButton->setText(QApplication::translate("TransportRegisterWindow", "Quit", Q_NULLPTR));
        logoutButton->setText(QApplication::translate("TransportRegisterWindow", "Log out", Q_NULLPTR));
        clearButton->setText(QApplication::translate("TransportRegisterWindow", "Clear", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class TransportRegisterWindow: public Ui_TransportRegisterWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_TRANSPORTREGISTERWINDOW_H
